

<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
            <div class="row">
                <div class="col-lg-12">
                    <a href="<?php echo e(url('status_kesehatan.create')); ?>" class="btn btn-xs btn-info pull-left ml-auto">Tambah</a>
                </div>
            </div>
            <div class="card-body">
                <?php if(session('status')): ?>
                <div class="row">
                  <div class="col-sm-12">
                    <div class="alert alert-success">
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <i class="material-icons">close</i>
                      </button>
                      <span><?php echo e(session('status')); ?></span>
                    </div>
                  </div>
                </div>
              <?php endif; ?>
                <div class="table-responsive">
                  <table class="table table-hover">
                    <thead class="">
                      <th>
                        Tanggal Pengisian
                      </th>
                      <th>
                        Nama
                      </th>
                      <th>
                        Aksi
                    </th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $hasil_kesehatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hasil_kesehatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr >
                            <td><?php echo e($hasil_kesehatan->tgl_mengisi); ?></td>
                            <td><?php echo e($hasil_kesehatan->nama); ?></td>
                            <th>
                               <a class="nav-link" href="<?php echo e(route('status_kesehatan.show',$hasil_kesehatan->id)); ?>">
                               <i class="material-icons">visibility</i> Lihat
                                  </a>
                                  <a class="nav-link" href="<?php echo e(route('status_kesehatan.hasil',[$hasil_kesehatan->tgl_mengisi,$hasil_kesehatan->pasien_id,])); ?>">
                                    <i class="material-icons">verified_user </i> Hasil
                                  </a>

                            </th>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                  </table>

                </form>

                </div>
              </div>
            </div>


  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Status Kesehatan', 'titlePage' => __('Status Kesehatan')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hicorev2\resources\views/pages/status_kesehatanIndex.blade.php ENDPATH**/ ?>