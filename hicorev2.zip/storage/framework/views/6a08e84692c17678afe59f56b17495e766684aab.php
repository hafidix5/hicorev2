


<?php $__env->startSection('content'); ?>
  <div class="content">
    
      <div class="row">
      <div class="container-fluid">
    <div class="card">
      <div class="card-header card-header-primary">
        <h4 class="card-title">Video Stress Hipertensi</h4>
      </div>
        <div class="col-md-12">

            <div class="card-body">
               
                <div class="table-responsive">
                  <table class="table table-hover">
                    <thead class="">
                        <th>
                            Nomor
                        </th>
                      <th>
                        Video
                      </th>
                      <th>
                        Nama
                      </th>
                    <th>
                        Aksi
                    </th>

                    </thead>
                    <tbody>
                    <?php $no=1; ?>
                        <?php $__currentLoopData = $response; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $response): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td>
                            <div class="embed-responsive embed-responsive-16by9">
                            <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/<?php echo e($response->video); ?>?rel=0" allowfullscreen></iframe>
                            </div>
                            </td>
                            <td><?php echo e($response->nama); ?></td>
                            <td>
                            
                                  <a class="nav-link" href="<?php echo e(route('video_stress.edit',$response->id)); ?>">
                                    <i class="material-icons">verified_user </i> Edit
                                  </a>
                                 
                                   <a class="nav-link" href="<?php echo e(route('video_stress.destroy',$response->id)); ?>">
                                    <i class="material-icons">remove_circle</i> Hapus
                                  </a>
                            </td>
                        </tr>
                        <php
                        $no++;
                         ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                  </table>

                </form>

                </div>
              </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <a href="<?php echo e(url('video_stress.insert')); ?>" class="btn btn-xs btn-info pull-left ml-auto">Tambah</a>
                </div>
            </div>

  </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', ['activePage' => '' , 'titlePage' => __('')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hicorev2\resources\views/pages/video_stress_admin.blade.php ENDPATH**/ ?>