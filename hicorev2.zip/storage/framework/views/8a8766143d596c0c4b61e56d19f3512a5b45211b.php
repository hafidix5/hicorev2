

<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card">
      <div class="card-header card-header-primary">
        <h4 class="card-title">Isi kuesioner Stres Pasien Hipertensi</h4>
      </div>

      <div class="card-body col-sm-10">
        <iframe src="<?php echo e(asset('material')); ?>/img/silence.mp3" type="audio/mp3" allow="autoplay" id="audio" style="display: none"></iframe>
        <audio id="player" autoplay loop>
          <source src="<?php echo e(asset('material')); ?>/img/hicore.mp3" type="audio/mp3">
      </audio>
        <?php if(session('status')): ?>
        <div class="row">
          <div class="col-sm-12">
            <div class="alert alert-success">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="material-icons">close</i>
              </button>
              <span><?php echo e(session('status')); ?></span>
            </div>
          </div>
        </div>
      <?php endif; ?>
        <div class="table-responsive">
          <table class="table table-hover">
            <thead class="">
              <th>
                Nomor
              </th>
              <th>
                Pertanyaan
              </th>
              <th>
                Jawaban&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp;
              </th>

            </thead>
            <tbody>
                <form method="post" action="<?php echo e(route('isi_stressSave')); ?>" autocomplete="off" class="form-horizontal">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('post'); ?>
            <?php $no=1; ?>
            <?php $__currentLoopData = $stress; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stress): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($stress->pertanyaan); ?></td>
                    <td class="text-left">
                        <span><input type="radio" id=<?php echo e($stress->id); ?> name=<?php echo e($stress->id); ?> value="0" required/> Tidak Pernah</span><br>
                        <span><input type="radio" id=<?php echo e($stress->id); ?> name=<?php echo e($stress->id); ?> value="1"/> Jarang</span><br/>
                       <span><input type="radio" id=<?php echo e($stress->id); ?> name=<?php echo e($stress->id); ?> value="2"/> Kadang-kadang</span>
                       <span><input type="radio" id=<?php echo e($stress->id); ?> name=<?php echo e($stress->id); ?> value="3"/> Sering</span><br/>
                       <span><input type="radio" id=<?php echo e($stress->id); ?> name=<?php echo e($stress->id); ?> value="4"/> Sangat Sering</span>
                   </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           

            </tbody>
          </table>
          <div class="card-footer ml-auto mr-auto">
            <button type="submit" class="btn btn-primary"><?php echo e(__('Simpan')); ?></button>
          </div>
        </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => '', 'titlePage' => __('')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hicorev2\resources\views/pages/isi_stress.blade.php ENDPATH**/ ?>