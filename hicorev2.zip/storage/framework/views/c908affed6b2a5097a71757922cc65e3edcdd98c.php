

<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
         <div class="card">
          <div class="card-header card-header-primary">
            <h4 class="card-title ">Hasil Rekomendasi Kuesioner</h4>
            <p class="card-category"></p>
          </div>
          <div class="card-body">
            <div class="container">
                <div class="row">
                  <div class="col-sm">
                    <div class="card text-center">
                        <h5 class="card-header">Pengetahuan Pasien Hipertensi</h5>
                        <div class="card-body ">
                            <a href="#" class="btn btn-primary disabled">
                                <?php $__currentLoopData = $pengetahuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($skor->pengetahuan); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </a>
                        </div>
                      </div>
                  </div>
                  <!-- <div class="col-sm">
                     <div class="card text-center">
                        <h5 class="card-header">Persepsi Pasien Hipertensi</h5>
                        <div class="card-body">
                            <a href="#" class="btn btn-primary disabled">
                             
                              </a>
                          </div>
                      </div>
                  </div>
                  <div class="col-sm">
                     <div class="card text-center">
                        <h5 class="card-header">Tingkat Kepatuhan Obat</h5>
                        <div class="card-body">
                            <a href="#" class="btn btn-primary disabled">
                              <?php $__currentLoopData = $skorHijau; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($skor->skorHijau); ?>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </a>
                          </div>
                      </div>
                  </div>
                  <div class="col-sm">
                    <div class="card text-center">
                       <h5 class="card-header">Penggunaan Obat-obatan</h5>
                       <div class="card-body">
                           <a href="#" class="btn btn-primary disabled">
                            <?php
                            $minumobat="";
                        ?>
                            <?php $__currentLoopData = $skorBiruMObat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php echo e($skor->skorBiruMObat); ?>

                             <?php if($skor->skorBiruMObat=="Tidak patuh"): ?>
                             <?php
                                $minumobat="Minum Obat, ";
                            ?>
                             <?php endif; ?>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </a>
                         </div>
                     </div>
                 </div>
                </div>
              </div>
              <div class="container">
                <div class="row">
                  <div class="col-sm">
                     <div class="card text-center">
                        <h5 class="card-header">Diet</h5>
                        <div class="card-body">
                            <a href="#" class="btn btn-primary disabled">
                                <?php
                                 $diet="";
                            ?>
                                <?php $__currentLoopData = $skorBiruMDiet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($skor->skorBiruMDiet); ?>

                              <?php if($skor->skorBiruMDiet=="Tidak patuh"): ?>
                              <?php
                                 $diet="yes";
                             ?>

                             <?php else: ?>
                              <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </a>
                          </div>
                      </div>
                  </div>
                  <div class="col-sm">
                     <div class="card text-center">
                        <h5 class="card-header">Aktifitas Fisik</h5>
                        <div class="card-body">
                            <a href="#" class="btn btn-primary disabled">
                                <?php
                                $aktifitas_fisik="";
                                $rekomendasidmo="";
                            ?>
                                <?php $__currentLoopData = $skorBiruMFisik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($skor->skorBiruMFisik); ?>

                              <?php if($skor->skorBiruMFisik=="Tidak patuh"): ?>
                              <?php
                                 $aktifitas_fisik="Aktifitas Fisik, ";
                             ?>

                             <?php else: ?>
                              <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </a>
                          </div>
                      </div>
                  </div>
                  <div class="col-sm">
                    <div class="card text-center">
                       <h5 class="card-header">Merokok</h5>
                       <div class="card-body">
                           <a href="#" class="btn btn-primary disabled">
                            <?php
                                $merokok="";
                            ?>
                            <?php $__currentLoopData = $skorBiruMRokok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php echo e($skor->skorBiruMRokok); ?>

                             <?php if($skor->skorBiruMRokok=="Tidak patuh"): ?>
                             <?php
                                $merokok="yes";
                            ?>

                            <?php else: ?>
                             <?php endif; ?>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </a>
                         </div>
                     </div>
                 </div>
                 <div class="col-sm">
                    <div class="card text-center">
                       <h5 class="card-header">Manajemen Berat Badan</h5>
                       <div class="card-body">
                           <a href="#" class="btn btn-primary disabled">
                            <?php
                                $manajemenbb="";
                            ?>

                            <?php $__currentLoopData = $skorNavyBB; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php echo e($skor->skorNavyBB); ?>

                             <?php if($skor->skorNavyBB=="Tidak patuh"): ?>
                             <?php
                                $manajemenbb="yes";
                            ?>

                            <?php else: ?>
                             <?php endif; ?>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </a>
                         </div>
                     </div>
                 </div>
                </div>
              </div>
              <div class="container">
                <div class="row">
                    <div class="col-sm">
                        <div class="card text-center">
                           <h5 class="card-header">Alkohol</h5>
                           <div class="card-body">
                               <a href="#" class="btn btn-primary disabled">
                                <?php
                                 $alkohol="";
                             ?>
                                <?php $__currentLoopData = $skorNavyAlkohol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php echo e($skor->skorNavyAlkohol); ?>

                                 <?php if($skor->skorNavyAlkohol=="Tidak patuh"): ?>
                              <?php
                                  $alkohol="yes";
                             ?>

                             <?php else: ?>
                              <?php endif; ?>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </a>
                             </div>
                         </div>
                     </div>
                  <div class="col-sm">
                     <div class="card text-center">
                        <h5 class="card-header">Stress Pasien Hipertensi</h5>
                        <div class="card-body">
                            <a href="#" class="btn btn-primary disabled">
                                <?php
                                $stress="";
                            ?>
                                <?php $__currentLoopData = $skorBiru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($skor->skorBiru); ?>

                              <?php if($skor->skorBiru!="Ringan"): ?>
                              <?php
                                 $stress="Pengendalian Stres Pada Hipertensi, ";
                             ?>

                             <?php else: ?>
                              <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </a>
                          </div>
                      </div>
                  </div>
                  <div class="col-sm">
                     <div class="card text-center">
                        <h5 class="card-header">Status Berat Badan</h5>
                        <div class="card-body">
                            <a href="#" class="btn btn-primary disabled">
                              <?php $__currentLoopData = $imt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($skor->imt); ?>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </a>
                          </div>
                      </div>
                  </div>
                  <div class="col-sm">
                     <div class="card text-center">
                        <h5 class="card-header">Tekanan Darah</h5>
                        <div class="card-body">
                            <a href="#" class="btn btn-primary disabled">
                                <?php
                                $hipetensiRekomendasi="";
                                $hipetensiRekomendasi2="";
                                $hipetensiRekomendasitopik="";
                            ?>
                                <?php $__currentLoopData = $tekanandarah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($skor->tekanandarah); ?>

                              <?php if(($skor->tekanandarah=="Hipertensi Derajat 1")||($skor->tekanandarah=="Hipertensi Derajat 2")): ?>
                              <?php
                                 $hipetensiRekomendasi="yes";
                                 $hipetensiRekomendasitopik="Pengenalan Hipertensi, Cara Mengukur Tekanan Darah, ";
                             ?>
                              <?php endif; ?>
                              <?php if($skor->tekanandarah=="Hipertensi Derajat 3"): ?>
                              <?php
                                 $hipetensiRekomendasi2="yes";
                             ?>
                              <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </a>
                          </div>
                      </div>
                  </div>

                </div>
              </div>
              <div class="container">
                <div class="row">
                    <div class="col-sm">
                        <div class="card text-center">
                           <h5 class="card-header">Rokok</h5>
                           <div class="card-body">
                               <a href="#" class="btn btn-primary disabled">
                                 <?php $__currentLoopData = $rokok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php echo e($skor->rokok); ?>

                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </a>
                             </div>
                         </div>
                     </div>
                  <div class="col-sm">
                     <div class="card text-center">
                        <h5 class="card-header">Obesitas</h5>
                        <div class="card-body">
                            <a href="#" class="btn btn-primary disabled">
                            <?php
                                 $obesitas2="";
                             ?>
                              <?php $__currentLoopData = $obesitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($skor->obesitas); ?>

                              <?php if($skor->obesitas=="Obesitas Sentral"): ?>
                              <?php
                                 $obesitas2="yes";
                             ?>

                             <?php else: ?>
                              <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </a>
                          </div>
                      </div>
                  </div>

                </div>
              </div>
              <?php if(($diet="yes")||($manajemenbb="yes")||($obesitas2="yes")): ?>
                <?php
                    $rekomendasidmo="Pengaturan Diet Hipertensi dan Cara Mengukur Berat Badan dan Lingkar Tubuh, ";
                ?>
              <?php endif; ?>
              <?php if(($merokok="yes")||($alkohol="yes")): ?>
              <?php
                  $rekomendasima="Pengenalan Bahaya Rokok dan Alkohol Pada Hipertensi, ";
              ?>
            <?php endif; ?>

              <h4>Rekomendasi :</h4>
              <?php if(($minumobat!="")|| ($aktifitas_fisik!="")|| ($rekomendasidmo!="")|| ($rekomendasima!="")||($stress!=""||($hipetensiRekomendasitopik!=""))): ?>
              <p>
                Silahkan bapak ibuk untuk mendengarkan kembali pendidikan kesehatan dengan topik <?php echo e($aktifitas_fisik); ?><?php echo e($minumobat); ?><?php echo e($rekomendasidmo); ?> <?php echo e($rekomendasima); ?> <?php echo e($stress); ?><?php echo e($hipetensiRekomendasitopik); ?>

              </p>
              <?php endif; ?>
              <p>
                Segera hubungi petugas kesehatan melalui link whatsapp untuk melakukan konsultasi bila ada yang tidak dipahami
              </p>
              <?php if($hipetensiRekomendasi=="yes"): ?>
              <p>
                Bapak/ibu tetap terus mengkonsumsi obat hipertensi secara teratur. Bila obat habis segeralah datang ke puskesmas/ dokter keluarga dan lakukan perubahan gaya hidup tidak sehat menjadi sehat
              </p>
              <?php endif; ?>
              <?php if($hipetensiRekomendasi2=="yes"): ?>
              <p>
                Segera dan jangan menunda untuk memeriksakan diri ke dokter
              </p>
              <?php endif; ?>
 -->


              <?php if(Auth::check()&& Auth::user()->role  == "2"): ?>
              <a href="<?php echo e(route('downloadHasilKuesioner',$pasien->nama)); ?>" class="btn btn-success my-3" target="_blank">EXPORT EXCEL</a>
              <h4>Pertanyaan kuesioner yang belum dijawab benar</h4>
              <div class="table-responsive">
              <table class="table">
                <thead class=" text-primary">
                  <th>
                    Nomor
                  </th>
                  <th>
                    Pertanyaan
                  </th>

                </thead>
                <tbody>
                    <?php $__currentLoopData = $response; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $response): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                        <td><?php echo e($response->id); ?></td>
                        <td><?php echo e($response->pertanyaan); ?></td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
              </table>
            </div>
            <?php endif; ?>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Riwayat Kuesioner', 'titlePage' => __('Riwayat Kuesioner')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hicorev2\resources\views/pages/riwayatKuesionerDetail.blade.php ENDPATH**/ ?>