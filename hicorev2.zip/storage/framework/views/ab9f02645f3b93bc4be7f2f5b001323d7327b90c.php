<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('login', [])->html();
} elseif ($_instance->childHasBeenRendered('nWPczQU')) {
    $componentId = $_instance->getRenderedChildComponentId('nWPczQU');
    $componentTag = $_instance->getRenderedChildComponentTagName('nWPczQU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('nWPczQU');
} else {
    $response = \Livewire\Livewire::mount('login', []);
    $html = $response->html();
    $_instance->logRenderedChild('nWPczQU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php /**PATH C:\laragon\www\hicorev2\resources\views/auth/login.blade.php ENDPATH**/ ?>