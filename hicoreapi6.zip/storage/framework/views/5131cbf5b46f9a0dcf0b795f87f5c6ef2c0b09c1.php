
<?php /**PATH C:\laragon\www\hicoreapi\resources\views/layouts/footers/guest.blade.php ENDPATH**/ ?>