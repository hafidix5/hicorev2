<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
         <div class="card">
          <div class="card-header card-header-primary">
            <h4 class="card-title ">Hasil Rekomendasi Kuesioner</h4>
            <p class="card-category"></p>
          </div>
          <div class="card-body">
            <div class="container">
                <div class="row">
                  <div class="col-sm">
                    <div class="card text-center">
                        <h5 class="card-header">Pengetahuan Pasien Hipertensi</h5>
                        <div class="card-body ">
                            <a href="#" class="btn btn-primary disabled">
                                <?php $__currentLoopData = $skorOren; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($skor->skorOren); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </a>


                        </div>
                      </div>
                  </div>
                  <div class="col-sm">
                     <div class="card text-center">
                        <h5 class="card-header">Persepsi Pasien Hipertensi</h5>
                        <div class="card-body">
                            <a href="#" class="btn btn-primary disabled">
                              <?php $__currentLoopData = $skorKuning; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($skor->skorKuning); ?>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </a>
                          </div>
                      </div>
                  </div>
                  <div class="col-sm">
                     <div class="card text-center">
                        <h5 class="card-header">Tingkat Kepatuhan Obat</h5>
                        <div class="card-body">
                            <a href="#" class="btn btn-primary disabled">
                              <?php $__currentLoopData = $skorHijau; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($skor->skorHijau); ?>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </a>
                          </div>
                      </div>
                  </div>
                  <div class="col-sm">
                    <div class="card text-center">
                       <h5 class="card-header">Penggunaan Obat-obatan</h5>
                       <div class="card-body">
                           <a href="#" class="btn btn-primary disabled">
                             <?php $__currentLoopData = $skorBiruMObat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php echo e($skor->skorBiruMObat); ?>

                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </a>
                         </div>
                     </div>
                 </div>
                </div>
              </div>
              <div class="container">
                <div class="row">
                  <div class="col-sm">
                     <div class="card text-center">
                        <h5 class="card-header">Diet</h5>
                        <div class="card-body">
                            <a href="#" class="btn btn-primary disabled">
                              <?php $__currentLoopData = $skorBiruMDiet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($skor->skorBiruMDiet); ?>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </a>
                          </div>
                      </div>
                  </div>
                  <div class="col-sm">
                     <div class="card text-center">
                        <h5 class="card-header">Aktifitas Fisik</h5>
                        <div class="card-body">
                            <a href="#" class="btn btn-primary disabled">
                              <?php $__currentLoopData = $skorBiruMFisik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($skor->skorBiruMFisik); ?>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </a>
                          </div>
                      </div>
                  </div>
                  <div class="col-sm">
                    <div class="card text-center">
                       <h5 class="card-header">Merokok</h5>
                       <div class="card-body">
                           <a href="#" class="btn btn-primary disabled">
                             <?php $__currentLoopData = $skorBiruMRokok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php echo e($skor->skorBiruMRokok); ?>

                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </a>
                         </div>
                     </div>
                 </div>
                 <div class="col-sm">
                    <div class="card text-center">
                       <h5 class="card-header">Manajemen Berat Badan</h5>
                       <div class="card-body">
                           <a href="#" class="btn btn-primary disabled">
                             <?php $__currentLoopData = $skorNavyBB; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php echo e($skor->skorNavyBB); ?>

                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </a>
                         </div>
                     </div>
                 </div>
                </div>
              </div>
              <div class="container">
                <div class="row">
                    <div class="col-sm">
                        <div class="card text-center">
                           <h5 class="card-header">Alkohol</h5>
                           <div class="card-body">
                               <a href="#" class="btn btn-primary disabled">
                                 <?php $__currentLoopData = $skorNavyAlkohol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php echo e($skor->skorNavyAlkohol); ?>

                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </a>
                             </div>
                         </div>
                     </div>
                  <div class="col-sm">
                     <div class="card text-center">
                        <h5 class="card-header">Stress Pasien Hipertensi</h5>
                        <div class="card-body">
                            <a href="#" class="btn btn-primary disabled">
                              <?php $__currentLoopData = $skorBiru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($skor->skorBiru); ?>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </a>
                          </div>
                      </div>
                  </div>
                  <div class="col-sm">
                     <div class="card text-center">
                        <h5 class="card-header">Indeks Masa Tubuh</h5>
                        <div class="card-body">
                            <a href="#" class="btn btn-primary disabled">
                              <?php $__currentLoopData = $imt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($skor->imt); ?>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </a>
                          </div>
                      </div>
                  </div>
                  <div class="col-sm">
                     <div class="card text-center">
                        <h5 class="card-header">Tekanan Darah</h5>
                        <div class="card-body">
                            <a href="#" class="btn btn-primary disabled">
                              <?php $__currentLoopData = $tekanandarah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($skor->tekanandarah); ?>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </a>
                          </div>
                      </div>
                  </div>

                </div>
              </div>
              <div class="container">
                <div class="row">
                    <div class="col-sm">
                        <div class="card text-center">
                           <h5 class="card-header">Rokok</h5>
                           <div class="card-body">
                               <a href="#" class="btn btn-primary disabled">
                                 <?php $__currentLoopData = $rokok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php echo e($skor->rokok); ?>

                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </a>
                             </div>
                         </div>
                     </div>
                  <div class="col-sm">
                     <div class="card text-center">
                        <h5 class="card-header">Obesitas</h5>
                        <div class="card-body">
                            <a href="#" class="btn btn-primary disabled">
                              <?php $__currentLoopData = $obesitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($skor->obesitas); ?>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </a>
                          </div>
                      </div>
                  </div>

                </div>
              </div>


          </div>
        </div>
      </div>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Riwayat Kuesioner', 'titlePage' => __('Riwayat Kuesioner')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hicoreapi\resources\views/pages/riwayatKuesionerDetailPasien.blade.php ENDPATH**/ ?>