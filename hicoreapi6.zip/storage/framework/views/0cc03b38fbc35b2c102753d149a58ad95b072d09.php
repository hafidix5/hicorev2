<div class="sidebar" data-color="orange" data-background-color="white" data-image="<?php echo e(asset('material')); ?>/img/sidebar-1.jpg">
  <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
  <div class="logo">
    <a href="#" class="simple-text logo-normal">
      <?php echo e(__('WEB HICORE')); ?>

    </a>
  </div>
  <div class="sidebar-wrapper">
    <ul class="nav">
        <?php if(Auth::check()&& Auth::user()->role  == "1"): ?>
        <li class="nav-item<?php echo e($activePage ?? ''); ?>">
            <a class="nav-link" href="<?php echo e(route('dataDiri')); ?>">
              <i class="material-icons">content_paste</i>
                <p><?php echo e(__('Data Diri')); ?></p>
            </a>
          </li>
      <li class="nav-item <?php echo e($activePage ?? ''); ?>">
        <div class="collapse show" id="laravelExample">
          <ul class="nav">
            <li class="nav-item<?php echo e($activePage ?? ''); ?>">
              <a class="nav-link" href="<?php echo e(route('profile.edit')); ?>">
                <i class="material-icons">perm_identity</i>
                <p><?php echo e(__('Profil')); ?></p>
              </a>
            </li>
          </ul>
        </div>
      </li>
      <li class="nav-item <?php echo e($activePage ?? ''); ?>">
        <div class="collapse show" id="laravelExample">
          <ul class="nav">
            <li class="nav-item<?php echo e($activePage ?? ''); ?>">
              <a class="nav-link" href="https://forms.gle/N44mhuwfwxNBDheQ9" target="_blank">
                <i class="material-icons">info</i>
                <p><?php echo e(__('Informed Concent')); ?></p>
              </a>
            </li>
          </ul>
        </div>
      </li>

      <li class="nav-item<?php echo e($activePage ?? ''); ?>">
        <a class="nav-link" href="<?php echo e(route('typography')); ?>">
          <i class="material-icons">library_books</i>
            <p><?php echo e(__('Isi Kuesioner')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage ?? ''); ?>">
        <a class="nav-link" href="<?php echo e(route('riwayat')); ?>">
          <i class="material-icons">content_paste</i>
            <p><?php echo e(__('Riwayat Kuesioner')); ?></p>
        </a>
      </li>

        <?php endif; ?>

      <?php if(Auth::check()&& Auth::user()->role  == "2"): ?>
      <li class="nav-item<?php echo e($activePage ?? ''); ?>">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">
          <i class="material-icons">dashboard</i>
            <p><?php echo e(__('Beranda')); ?></p>
        </a>
      </li>
    </li>
    <li class="nav-item <?php echo e($activePage ?? ''); ?>">
      <div class="collapse show" id="laravelExample">
        <ul class="nav">
          <li class="nav-item<?php echo e($activePage ?? ''); ?>">
            <a class="nav-link" href="<?php echo e(route('profile.edit')); ?>">
              <i class="material-icons">perm_identity</i>
              <p><?php echo e(__('Profil')); ?></p>
            </a>
          </li>
        </ul>
      </div>
    </li>

      <li class="nav-item<?php echo e($activePage ?? ''); ?>">
          <a class="nav-link" href="<?php echo e(route('table')); ?>">
            <i class="material-icons">face</i>
            <p><?php echo e(__('Hasil Kuesioner Pasien')); ?></p>
          </a>
        </li>

      <?php endif; ?>
      <li class="nav-item<?php echo e($activePage ?? ''); ?>">
        <a class="nav-link" href="<?php echo e(route('pendidikanKesehatan')); ?>">
          <i class="material-icons">face</i>
          <p><?php echo e(__('Pendidikan Kesehatan')); ?></p>
        </a>
      </li>
      <li class="nav-item<?php echo e($activePage ?? ''); ?>">
        <a class="nav-link" href="pilihGroup">
            <i class="material-icons">chat</i>
            <p><?php echo e(__('Konsultasi Group WA')); ?></p>
          </a>
      </li>
      <li class="nav-item<?php echo e($activePage ?? ''); ?>">
        <a class="nav-link" href="https://forms.gle/fUwmVfFg3e3k7TLV9" target="_blank">
            <i class="material-icons">feedback</i>
            <p><?php echo e(__('Tanggapan')); ?></p>
          </a>
      </li>
      <li class="nav-item<?php echo e($activePage ?? ''); ?>">
        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();"><?php echo e(__('Log out')); ?></a>
      </li>

    </ul>
  </div>
</div>
<?php /**PATH C:\laragon\www\hicoreapi\resources\views/layouts/navbars/sidebar.blade.php ENDPATH**/ ?>