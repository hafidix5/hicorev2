<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <form method="post" action="<?php echo e(route('pasien.store')); ?>" autocomplete="off" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>

            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Data Pasien')); ?></h4>
              </div>
              <div class="card-body ">
                <iframe src="<?php echo e(asset('material')); ?>/img/silence.mp3" type="audio/mp3" allow="autoplay" id="audio" style="display: none"></iframe>
                <audio id="player" autoplay loop>
                  <source src="<?php echo e(asset('material')); ?>/img/hicore.mp3" type="audio/mp3">
              </audio>
                <?php if(session('status')): ?>
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <i class="material-icons">close</i>
                        </button>
                        <span><?php echo e(session('status')); ?></span>
                      </div>
                    </div>
                  </div>
                <?php endif; ?>
                <div class="row">
                  <label class="col-sm-2 col-form-label"><?php echo e(__('Nama Lengkap')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('nama') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('nama') ? ' is-invalid' : ''); ?>" name="nama" id="input-nama" type="text" placeholder="<?php echo e(__('Nama')); ?>" value="<?php echo e(old('name', auth()->user()->name)); ?>" required="true" aria-required="true"/>
                      <?php if($errors->has('nama')): ?>
                        <span id="nama-error" class="error text-danger" for="input-nama"><?php echo e($errors->first('nama')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-2 col-form-label"><?php echo e(__('HP')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('hp') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('hp') ? ' is-invalid' : ''); ?>" name="hp" id="input-hp" type="phone" value="<?php echo e(old('email', auth()->user()->email)); ?>" value="" required />
                      <?php if($errors->has('hp')): ?>
                        <span id="hp-error" class="error text-danger" for="input-hp"><?php echo e($errors->first('hp')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Tanggal lahir')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('tgl_lahir') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('tgl_lahir') ? ' is-invalid' : ''); ?>" name="tgl_lahir" id="input-tgl_lahir" type="date" placeholder="<?php echo e(__('')); ?>" value="" required />
                        <?php if($errors->has('tgl_lahir')): ?>
                          <span id="tgl_lahir-error" class="error text-danger" for="input-tgl_lahir"><?php echo e($errors->first('tgl_lahir')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Jenis kelamin')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('jk') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="jk" id="jk">
                          <option value="laki-laki">Laki-laki</option>
                          <option value="perempuan">Perempuan</option>
                        </select>
                        <?php if($errors->has('jk')): ?>
                          <span id="jk-error" class="error text-danger" for="input-jk"><?php echo e($errors->first('jk')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Tinggi')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('tinggi') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('tinggi') ? ' is-invalid' : ''); ?>" name="tinggi" id="input-tinggi" type="number" placeholder="<?php echo e(__('tinggi (cm)')); ?>" value="" required />
                        <?php if($errors->has('tinggi')): ?>
                          <span id="tinggi-error" class="error text-danger" for="input-tinggi"><?php echo e($errors->first('tinggi')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Berat')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('berat') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('berat') ? ' is-invalid' : ''); ?>" name="berat" id="input-berat" type="number" placeholder="<?php echo e(__('berat (kg)')); ?>" value="" required />
                        <?php if($errors->has('berat')): ?>
                          <span id="berat-error" class="error text-danger" for="input-berat"><?php echo e($errors->first('berat')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Alamat')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('alamat') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('alamat') ? ' is-invalid' : ''); ?>" name="alamat" id="input-alamat" type="text" placeholder="<?php echo e(__('alamat tempat tinggal')); ?>" value="" required />
                        <?php if($errors->has('alamat')): ?>
                          <span id="alamat-error" class="error text-danger" for="input-alamat"><?php echo e($errors->first('alamat')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Pekerjaan')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('pekerjaan') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="pekerjaan" id="pekerjaan">

                          <option value="Ibu rumah tangga">Ibu rumah tangga</option>
                          <option value="Pensiunan">Pensiunan</option>
                          <option value="PNS">PNS</option>
                          <option value="Petani/Buruh">Petani/Buruh</option>
                          <option value="Wiraswasta">Wiraswasta</option>
                          <option value="Tidak bekerja">Tidak bekerja</option>
                        </select>
                        <?php if($errors->has('pekerjaan')): ?>
                          <span id="pekerjaan-error" class="error text-danger" for="input-pekerjaan"><?php echo e($errors->first('pekerjaan')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Pendidikan')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('pendidikan') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="pendidikan" id="pendidikan">

                          <option value="Tidak Sekolah">Tidak Sekolah</option>
                          <option value="SD">SD</option>
                          <option value="SMP">SMP</option>
                          <option value="SMA">SMA</option>
                          <option value="Perguruan Tinggi">Perguruan Tinggi</option>
                        </select>
                        <?php if($errors->has('pendidikan')): ?>
                          <span id="pendidikan-error" class="error text-danger" for="input-pendidikan"><?php echo e($errors->first('pendidikan')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Riwayat Hipertensi Keluarga')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('riwayat_hipertensi_kel') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="riwayat_hipertensi_kel" id="riwayat_hipertensi_kel">

                          <option value="ada">Ada</option>
                          <option value="tidak">Tidak</option>
                          </select>
                        <?php if($errors->has('riwayat_hipertensi_kel')): ?>
                          <span id="riwayat_hipertensi_kel-error" class="error text-danger" for="input-riwayat_hipertensi_kel"><?php echo e($errors->first('riwayat_hipertensi_kel')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Lama Hipertensi')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('lama_hipertensi') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('lama_hipertensi') ? ' is-invalid' : ''); ?>" name="lama_hipertensi" id="input-lama_hipertensi" type="number" placeholder="<?php echo e(__('lama hipertensi (bulan)')); ?>" value="" required />
                        <?php if($errors->has('lama_hipertensi')): ?>
                          <span id="lama_hipertensi-error" class="error text-danger" for="input-lama_hipertensi"><?php echo e($errors->first('lama_hipertensi')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Tinggal bersama')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('tinggal_dengan') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="tinggal_dengan" id="tinggal_dengan">

                          <option value="pasangan">Pasangan</option>
                          <option value="sendiri">Sendiri</option>
                          <option value="anak">Anak</option>
                          <option value="saudara">Saudara</option>
                          </select>
                        <?php if($errors->has('tinggal_dengan')): ?>
                          <span id="tinggal_dengan-error" class="error text-danger" for="input-tinggal_dengan"><?php echo e($errors->first('tinggal_dengan')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Tanggal pemeriksaan terakhir')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('tgl_pemeriksaan_terakhir') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('tgl_pemeriksaan_terakhir') ? ' is-invalid' : ''); ?>" name="tgl_pemeriksaan_terakhir" id="input-tgl_pemeriksaan_terakhir" type="date" placeholder="<?php echo e(__('')); ?>" value="" required />
                        <?php if($errors->has('tgl_pemeriksaan_terakhir')): ?>
                          <span id="tgl_pemeriksaan_terakhir-error" class="error text-danger" for="input-tgl_pemeriksaan_terakhir"><?php echo e($errors->first('tgl_pemeriksaan_terakhir')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Tekanan darah')); ?></label>
                    <div class="col-sm-2">
                      <div class="form-group<?php echo e($errors->has('pemeriksaan_satu') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('pemeriksaan_satu') ? ' is-invalid' : ''); ?>" name="pemeriksaan_satu" id="input-pemeriksaan_satu" type="number" maxlength="3" placeholder="<?php echo e(__('sistol')); ?>" value="" required />
                        <input class="form-control<?php echo e($errors->has('pemeriksaan_dua') ? ' is-invalid' : ''); ?>" name="pemeriksaan_dua" id="input-pemeriksaan_dua" type="number" maxlength="3" placeholder="<?php echo e(__('diastol')); ?>" value="" required />mmhg
                        <?php if($errors->has('pemeriksaan_satu')): ?>
                          <span id="pemeriksaan_satu-error" class="error text-danger" for="input-pemeriksaan_satu"><?php echo e($errors->first('pemeriksaan_satu')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Apakah anda merokok ?')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('merokok') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="merokok" id="merokok">

                          <option value="ya">Ya</option>
                          <option value="tidak">Tidak</option>
                          </select>
                        <?php if($errors->has('merokok')): ?>
                          <span id="merokok-error" class="error text-danger" for="input-merokok"><?php echo e($errors->first('merokok')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Lama merokok')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('lama_merokok') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('lama_merokok') ? ' is-invalid' : ''); ?>" name="lama_merokok" id="input-lama_merokok" type="number" placeholder="<?php echo e(__('lama merokok (tahun)')); ?>" value="" required />
                        <?php if($errors->has('lama_merokok')): ?>
                          <span id="lama_merokok-error" class="error text-danger" for="input-lama_merokok"><?php echo e($errors->first('lama_merokok')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Jumlah batang rokok yang dikonsumsi per hari')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('rokokperhari') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('rokokperhari') ? ' is-invalid' : ''); ?>" name="rokokperhari" id="input-rokokperhari" type="number" placeholder="<?php echo e(__('rokok per hari (batang)')); ?>" value="" required />
                        <?php if($errors->has('rokokperhari')): ?>
                          <span id="rokokperhari-error" class="error text-danger" for="input-rokokperhari"><?php echo e($errors->first('rokokperhari')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Lingkar perut')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('lingkar_perut') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('lingkar_perut') ? ' is-invalid' : ''); ?>" name="lingkar_perut" id="input-lingkar_perut" type="number" placeholder="<?php echo e(__('lingkar perut (cm)')); ?>" value="" required />
                        <?php if($errors->has('lingkar_perut')): ?>
                          <span id="lingkar_perut-error" class="error text-danger" for="input-lingkar_perut"><?php echo e($errors->first('lingkar_perut')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Penyakit lain')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('penyakit_lain') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('penyakit_lain') ? ' is-invalid' : ''); ?>" name="penyakit_lain" id="input-penyakit_lain" type="text" placeholder="<?php echo e(__('')); ?>" value="" required />
                        <?php if($errors->has('penyakit_lain')): ?>
                          <span id="penyakit_lain-error" class="error text-danger" for="input-penyakit_lain"><?php echo e($errors->first('penyakit_lain')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Teratur kontrol')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('teratur_kontrol') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="teratur_kontrol" id="teratur_kontrol">

                          <option value="iya">Iya</option>
                          <option value="tidak">Tidak</option>
                          </select>
                        <?php if($errors->has('teratur_kontrol')): ?>
                          <span id="teratur_kontrol-error" class="error text-danger" for="input-teratur_kontrol"><?php echo e($errors->first('teratur_kontrol')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Obat yang dikonsumsi')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('konsumsi_obat') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('konsumsi_obat') ? ' is-invalid' : ''); ?>" name="konsumsi_obat" id="input-konsumsi_obat" type="text" placeholder="<?php echo e(__('')); ?>" value="" required />
                        <?php if($errors->has('konsumsi_obat')): ?>
                          <span id="konsumsi_obat-error" class="error text-danger" for="input-konsumsi_obat"><?php echo e($errors->first('konsumsi_obat')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label"><?php echo e(__('Puskesmas')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('puskesmas_id') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="puskesmas_id" id="puskesmas_id">

                            <?php $__currentLoopData = $puskesmas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $puskesmas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> {
                          <option value="<?php echo e($puskesmas->id); ?>"><?php echo e($puskesmas->nama); ?></option>
                            }
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        <?php if($errors->has('puskesmas_id')): ?>
                          <span id="puskesmas_id-error" class="error text-danger" for="input-puskesmas_id"><?php echo e($errors->first('puskesmas_id')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('user_id') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('user_id') ? ' is-invalid' : ''); ?>" name="user_id" id="user_id" type="text" placeholder="<?php echo e(__('')); ?>" value="<?php echo e(old('name', auth()->user()->id)); ?>" required="true" aria-required="true" hidden/>
                        <?php if($errors->has('user_id')): ?>
                          <span id="user_id-error" class="error text-danger" for="input-user_id"><?php echo e($errors->first('user_id')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>



              </div>
              <div class="card-footer ml-auto mr-auto">
                <button type="submit" class="btn btn-primary"><?php echo e(__('Simpan')); ?></button>
              </div>
            </div>
          </form>
        </div>
      </div>

    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Data Diri', 'titlePage' => __('Data Diri')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hicoreapi\resources\views/pages/dataDiri.blade.php ENDPATH**/ ?>