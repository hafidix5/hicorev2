<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card">
      <div class="card-header card-header-primary">
        <h4 class="card-title">Penyuluhan</h4>
        <p class="card-category">Pendidikan Kesehatan</p>
      </div>

      <div class="card-body">
        <?php if(session('status')): ?>
        <div class="row">
          <div class="col-sm-12">
            <div class="alert alert-success">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="material-icons">close</i>
              </button>
              <span><h4><?php echo e(session('status')); ?><h4>

            </span>
            </div>
          </div>
        </div>
      <?php endif; ?>
      <?php $__currentLoopData = $response; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $response): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <h4><?php echo e($response->id); ?>. <?php echo e($response->nama); ?></h4>
      <div class="embed-responsive embed-responsive-16by9">
      <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/<?php echo e($response->file); ?>?rel=0" allowfullscreen></iframe>
      </div>

      <br><br>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => '', 'titlePage' => __('')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hicoreapi\resources\views/pages/pendidikanKesehatan.blade.php ENDPATH**/ ?>