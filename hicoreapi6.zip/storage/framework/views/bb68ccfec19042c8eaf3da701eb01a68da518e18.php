<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card">
      <div class="card-header card-header-primary">
        <h4 class="card-title">Ramodif</h4>
        <p class="card-category">Rawat dan Modifikasi</p>
      </div>

      <div class="card-body">
        <?php if(session('status')): ?>
        <div class="row">
          <div class="col-sm-12">
            <div class="alert alert-success">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="material-icons">close</i>
              </button>
              <span><?php echo e(session('status')); ?></span>
            </div>
          </div>
        </div>
      <?php endif; ?>
        <div class="table-responsive">
          <table class="table table-hover">
            <thead class="">
              <th>
                Nomor
              </th>
              <th>
                Pertanyaan
              </th>
              <th>
                Jawaban&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp;
              </th>

            </thead>
            <tbody>
                <form method="post" action="<?php echo e(route('isi_kuesionerSave')); ?>" autocomplete="off" class="form-horizontal">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('post'); ?>

            <?php $__currentLoopData = $kuesionerOren; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kuesionerOren): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($kuesionerOren->id); ?></td>
                    <td><?php echo e($kuesionerOren->pertanyaan); ?></td>
                    <td class="text-left">
                        <span><input type="radio" id=<?php echo e($kuesionerOren->id); ?> name=<?php echo e('pertanyaan'.$kuesionerOren->id); ?> value="1" required/> Benar</span><br>
                        <span><input type="radio" id=<?php echo e($kuesionerOren->id); ?> name=<?php echo e('pertanyaan'.$kuesionerOren->id); ?> value="0"/> Salah</span><br/>
                       <span><input type="radio" id=<?php echo e($kuesionerOren->id); ?> name=<?php echo e('pertanyaan'.$kuesionerOren->id); ?> value="0"/> Tidak Tahu</span>
                   </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $kuesionerKuning; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kuesionerKuning): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($kuesionerKuning->id); ?></td>
                    <td><?php echo e($kuesionerKuning->pertanyaan); ?></td>
                    <td class="text-left">
                        <span><input type="radio" id=<?php echo e($kuesionerKuning->id); ?> name=<?php echo e('pertanyaan'.$kuesionerKuning->id); ?> value="1"  required/> Sangat Setuju</span><br>
                        <span><input type="radio" id=<?php echo e($kuesionerKuning->id); ?> name=<?php echo e('pertanyaan'.$kuesionerKuning->id); ?> value="0"/> Ragu-ragu</span><br/>
                       <span><input type="radio" id=<?php echo e($kuesionerKuning->id); ?> name=<?php echo e('pertanyaan'.$kuesionerKuning->id); ?> value="0"/> Tidak Setuju</span>
                   </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php $__currentLoopData = $kuesionerHijau; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kuesionerHijau): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($kuesionerHijau->id); ?></td>
                <td><?php echo e($kuesionerHijau->pertanyaan); ?></td>
                <td class="text-left">
                    <span><input type="radio" id=<?php echo e($kuesionerHijau->id); ?> name=<?php echo e('pertanyaan'.$kuesionerHijau->id); ?> value="1"  required/> Iya </span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerHijau->id); ?> name=<?php echo e('pertanyaan'.$kuesionerHijau->id); ?> value="0"/> Tidak</span><br/>
               </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php $__currentLoopData = $kuesionerBiruMObat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kuesionerBiruMObat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($kuesionerBiruMObat->id); ?></td>
                <td><?php echo e($kuesionerBiruMObat->pertanyaan); ?></td>
                <td class="text-left">
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="1"  required/> Sangat tidak setuju</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="2"/> Tidak setuju</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="3"/> Tidak yakin</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="4"/> Setuju</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="5"/> Sangat setuju</span><br>
               </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $kuesionerBiruMDiet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kuesionerBiruMDiet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($kuesionerBiruMDiet->id); ?></td>
                <td><?php echo e($kuesionerBiruMDiet->pertanyaan); ?></td>
                <td class="text-left">
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="1"  required/> Sangat tidak setuju</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="2"/> Tidak setuju</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="3"/> Tidak yakin</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="4"/> Setuju</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="5"/> Sangat setuju</span><br>
               </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $kuesionerBiruMFisik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kuesionerBiruMFisik): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($kuesionerBiruMFisik->id); ?></td>
                <td><?php echo e($kuesionerBiruMFisik->pertanyaan); ?></td>
                <td class="text-left">
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="1"  required/> Sangat tidak setuju</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="2"/> Tidak setuju</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="3"/> Tidak yakin</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="4"/> Setuju</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="5"/> Sangat setuju</span><br>
               </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $kuesionerBiruMRokok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kuesionerBiruMRokok): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($kuesionerBiruMRokok->id); ?></td>
                <td><?php echo e($kuesionerBiruMRokok->pertanyaan); ?></td>
                <td class="text-left">
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="1"  required/> Sangat tidak setuju</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="2"/> Tidak setuju</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="3"/> Tidak yakin</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="4"/> Setuju</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="5"/> Sangat setuju</span><br>
               </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $kuesionerNavyBB; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kuesionerNavyBB): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($kuesionerNavyBB->id); ?></td>
                <td><?php echo e($kuesionerNavyBB->pertanyaan); ?></td>
                <td class="text-left">
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="1"  required/> Sangat tidak setuju</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="2"/> Tidak setuju</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="3"/> Tidak yakin</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="4"/> Setuju</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="5"/> Sangat setuju</span><br>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $kuesionerNavyAlkohol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kuesionerNavyAlkohol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($kuesionerNavyAlkohol->id); ?></td>
                <td><?php echo e($kuesionerNavyAlkohol->pertanyaan); ?></td>
                <td class="text-left">
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="1"  required/> Sangat tidak setuju</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="2"/> Tidak setuju</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="3"/> Tidak yakin</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="4"/> Setuju</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="5"/> Sangat setuju</span><br>
                </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $kuesionerNavyAlkoholbotol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kuesionerNavyAlkoholbotol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($kuesionerNavyAlkoholbotol->id); ?></td>
                <td><?php echo e($kuesionerNavyAlkoholbotol->pertanyaan); ?></td>
                <td class="text-left">
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="1"  required/> Sangat tidak setuju</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="2"/> Tidak setuju</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="3"/> Tidak yakin</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="4"/> Setuju</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiruMObat->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiruMObat->id); ?> value="5"/> Sangat setuju</span><br>
                </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $kuesionerNavyAlkoholtotal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kuesionerNavyAlkoholtotal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($kuesionerNavyAlkoholtotal->id); ?></td>
                <td><?php echo e($kuesionerNavyAlkoholtotal->pertanyaan); ?></td>
                <td class="text-left">
                    <span><input type="number" id=<?php echo e($kuesionerNavyAlkoholtotal->id); ?> name=<?php echo e('pertanyaan'.$kuesionerNavyAlkoholtotal->id); ?> value="" placeholder="sloki" required/> </span>&nbsp;
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $kuesionerNavyAlkoholmerek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kuesionerNavyAlkoholmerek): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($kuesionerNavyAlkoholmerek->id); ?></td>
                <td><?php echo e($kuesionerNavyAlkoholmerek->pertanyaan); ?></td>
                <td class="text-left">
                    <span><input type="text" id=<?php echo e($kuesionerNavyAlkoholmerek->id); ?> name=<?php echo e('pertanyaan'.$kuesionerNavyAlkoholmerek->id); ?> value="" placeholder="merek" required/> </span>&nbsp;
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $kuesionerBiru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kuesionerBiru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($kuesionerBiru->id); ?></td>
                <td><?php echo e($kuesionerBiru->pertanyaan); ?></td>
                <td class="text-left">
                    <span><input type="radio" id=<?php echo e($kuesionerBiru->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiru->id); ?> value="0" required/> Tidak pernah</span><br>
                    <span><input type="radio" id=<?php echo e($kuesionerBiru->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiru->id); ?> value="1"/> Jarang</span><br/>
                    <span><input type="radio" id=<?php echo e($kuesionerBiru->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiru->id); ?> value="2"/> Kadang-kadang Yakin</span><br/>
                    <span><input type="radio" id=<?php echo e($kuesionerBiru->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiru->id); ?> value="3"/> Sering</span><br/>
                    <span><input type="radio" id=<?php echo e($kuesionerBiru->id); ?> name=<?php echo e('pertanyaan'.$kuesionerBiru->id); ?> value="4"/> Sangat Sering</span><br/>
               </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
          </table>
          <div class="card-footer ml-auto mr-auto">
            <button type="submit" class="btn btn-primary"><?php echo e(__('Simpan')); ?></button>
          </div>
        </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Isi kuesioner', 'titlePage' => __('Isi kuesioner')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hicoreapi\resources\views/pages/typography.blade.php ENDPATH**/ ?>