@extends('layouts.app', ['activePage' => 'Data Diri', 'titlePage' => __('Data Diri')])

@section('content')
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <form method="post" action="{{ route('pasien.update') }}" autocomplete="off" class="form-horizontal">
            @csrf
            @method('post')

            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title">{{ __('Data Pasien') }}</h4>
              </div>
              <div class="card-body ">
                <iframe src="{{ asset('material') }}/img/silence.mp3" type="audio/mp3" allow="autoplay" id="audio" style="display: none"></iframe>
                <audio id="player" autoplay loop>
                  <source src="{{ asset('material') }}/img/hicore.mp3" type="audio/mp3">
              </audio>
                @if (session('status'))
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <i class="material-icons">close</i>
                        </button>
                        <span>{{ session('status') }}</span>
                      </div>
                    </div>
                  </div>
                @endif
                <input type="hidden" name="id" value="{{ $pasien->id }}">
                <div class="row">
                  <label class="col-sm-2 col-form-label">{{ __('Nama Lengkap') }}</label>
                  <div class="col-sm-7">
                    <div class="form-group{{ $errors->has('nama') ? ' has-danger' : '' }}">
                      <input class="form-control{{ $errors->has('nama') ? ' is-invalid' : '' }}" name="nama" id="input-nama" type="text" placeholder="{{ __('Nama') }}" value="{{ old('name', auth()->user()->name) }}" required="true" aria-required="true" readonly/>
                      @if ($errors->has('nama'))
                        <span id="nama-error" class="error text-danger" for="input-nama">{{ $errors->first('nama') }}</span>
                      @endif
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-2 col-form-label">{{ __('HP') }}</label>
                  <div class="col-sm-7">
                    <div class="form-group{{ $errors->has('hp') ? ' has-danger' : '' }}">
                      <input class="form-control{{ $errors->has('hp') ? ' is-invalid' : '' }}" name="hp" id="input-hp" type="phone" placeholder="{{ __('Nomor HP') }}" value="{{ $pasien->hp ?? '' }}" required />
                      @if ($errors->has('hp'))
                        <span id="hp-error" class="error text-danger" for="input-hp">{{ $errors->first('hp') }}</span>
                      @endif
                    </div>
                  </div>
                </div>
                <div class="row">
                    <label class="col-sm-2 col-form-label">{{ __('Tanggal lahir') }}</label>
                    <div class="col-sm-7">
                      <div class="form-group{{ $errors->has('tgl_lahir') ? ' has-danger' : '' }}">
                        <input class="form-control{{ $errors->has('tgl_lahir') ? ' is-invalid' : '' }}" name="tgl_lahir" id="input-tgl_lahir" type="date" placeholder="{{ __('') }}" value="{{ $pasien->tgl_lahir ?? ''  }}" required />
                        @if ($errors->has('tgl_lahir'))
                          <span id="tgl_lahir-error" class="error text-danger" for="input-tgl_lahir">{{ $errors->first('tgl_lahir') }}</span>
                        @endif
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label">{{ __('Jenis kelamin') }}</label>
                    <div class="col-sm-7">
                      <div class="form-group{{ $errors->has('jk') ? ' has-danger' : '' }}">
                        <select name="jk" id="jk">
                          @if($pasien->jk)
                          <option value="{{ $pasien->jk ?? ''  }}" selected>{{ $pasien->jk ?? ''  }}</option>
                          <option value="laki-laki">Laki-laki</option>
                          <option value="perempuan">Perempuan</option>
                          @endif
                        </select>
                        @if ($errors->has('jk'))
                          <span id="jk-error" class="error text-danger" for="input-jk">{{ $errors->first('jk') }}</span>
                        @endif
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label">{{ __('Tinggi') }}</label>
                    <div class="col-sm-7">
                      <div class="form-group{{ $errors->has('tinggi') ? ' has-danger' : '' }}">
                        <input class="form-control{{ $errors->has('tinggi') ? ' is-invalid' : '' }}" name="tinggi" id="input-tinggi" type="number" placeholder="{{ __('tinggi (cm)') }}" value="{{ $pasien->tinggi ?? ''  }}" required />
                        @if ($errors->has('tinggi'))
                          <span id="tinggi-error" class="error text-danger" for="input-tinggi">{{ $errors->first('tinggi') }}</span>
                        @endif
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label">{{ __('Berat') }}</label>
                    <div class="col-sm-7">
                      <div class="form-group{{ $errors->has('berat') ? ' has-danger' : '' }}">
                        <input class="form-control{{ $errors->has('berat') ? ' is-invalid' : '' }}" name="berat" id="input-berat" type="number" placeholder="{{ __('berat (kg)') }}" value="{{ $pasien->berat ?? ''  }}" required />
                        @if ($errors->has('berat'))
                          <span id="berat-error" class="error text-danger" for="input-berat">{{ $errors->first('berat') }}</span>
                        @endif
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label">{{ __('Alamat') }}</label>
                    <div class="col-sm-7">
                      <div class="form-group{{ $errors->has('alamat') ? ' has-danger' : '' }}">
                        <input class="form-control{{ $errors->has('alamat') ? ' is-invalid' : '' }}" name="alamat" id="input-alamat" type="text" placeholder="{{ __('alamat tempat tinggal') }}" value="{{ $pasien->alamat ?? ''  }}" required />
                        @if ($errors->has('alamat'))
                          <span id="alamat-error" class="error text-danger" for="input-alamat">{{ $errors->first('alamat') }}</span>
                        @endif
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label">{{ __('Pekerjaan') }}</label>
                    <div class="col-sm-7">
                      <div class="form-group{{ $errors->has('pekerjaan') ? ' has-danger' : '' }}">
                        <select name="pekerjaan" id="pekerjaan">
                          @if($pasien->pekerjaan)
                          <option value="{{ $pasien->pekerjaan ?? ''  }}" selected>{{ $pasien->pekerjaan ?? ''  }}</option>
                          @endif
                          <option value="Ibu rumah tangga">Ibu rumah tangga</option>
                          <option value="Pensiunan">Pensiunan</option>
                          <option value="PNS">PNS</option>
                          <option value="Petani/Buruh">Petani/Buruh</option>
                          <option value="Wiraswasta">Wiraswasta</option>
                          <option value="Tidak bekerja">Tidak bekerja</option>
                        </select>
                        @if ($errors->has('pekerjaan'))
                          <span id="pekerjaan-error" class="error text-danger" for="input-pekerjaan">{{ $errors->first('pekerjaan') }}</span>
                        @endif
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label">{{ __('Pendidikan') }}</label>
                    <div class="col-sm-7">
                      <div class="form-group{{ $errors->has('pendidikan') ? ' has-danger' : '' }}">
                        <select name="pendidikan" id="pendidikan">
                            @if($pasien->pendidikan)
                            <option value="{{ $pasien->pendidikan ?? ''  }}" selected>{{ $pasien->pendidikan ?? ''  }}</option>
                            @endif
                          <option value="Tidak Sekolah">Tidak Sekolah</option>
                          <option value="SD">SD</option>
                          <option value="SMP">SMP</option>
                          <option value="SMA">SMA</option>
                          <option value="Perguruan Tinggi">Perguruan Tinggi</option>
                        </select>
                        @if ($errors->has('pendidikan'))
                          <span id="pendidikan-error" class="error text-danger" for="input-pendidikan">{{ $errors->first('pendidikan') }}</span>
                        @endif
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label">{{ __('Riwayat Hipertensi Keluarga') }}</label>
                    <div class="col-sm-7">
                      <div class="form-group{{ $errors->has('riwayat_hipertensi_kel') ? ' has-danger' : '' }}">
                        <select name="riwayat_hipertensi_kel" id="riwayat_hipertensi_kel">
                            @if($pasien->riwayat_hipertensi_kel)
                            <option value="{{ $pasien->riwayat_hipertensi_kel ?? ''  }}" selected>{{ $pasien->riwayat_hipertensi_kel ?? ''  }}</option>
                            @endif
                          <option value="ada">Ada</option>
                          <option value="tidak">Tidak</option>
                          </select>
                        @if ($errors->has('riwayat_hipertensi_kel'))
                          <span id="riwayat_hipertensi_kel-error" class="error text-danger" for="input-riwayat_hipertensi_kel">{{ $errors->first('riwayat_hipertensi_kel') }}</span>
                        @endif
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label">{{ __('Lama Hipertensi') }}</label>
                    <div class="col-sm-7">
                      <div class="form-group{{ $errors->has('lama_hipertensi') ? ' has-danger' : '' }}">
                        <input class="form-control{{ $errors->has('lama_hipertensi') ? ' is-invalid' : '' }}" name="lama_hipertensi" id="input-lama_hipertensi" type="number" placeholder="{{ __('lama hipertensi (bulan)') }}" value="{{ $pasien->lama_hipertensi ?? ''  }}" required />
                        @if ($errors->has('lama_hipertensi'))
                          <span id="lama_hipertensi-error" class="error text-danger" for="input-lama_hipertensi">{{ $errors->first('lama_hipertensi') }}</span>
                        @endif
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label">{{ __('Tinggal bersama') }}</label>
                    <div class="col-sm-7">
                      <div class="form-group{{ $errors->has('tinggal_dengan') ? ' has-danger' : '' }}">
                        <select name="tinggal_dengan" id="tinggal_dengan">
                            @if($pasien->tinggal_dengan)
                            <option value="{{ $pasien->tinggal_dengan ?? ''  }}" selected>{{ $pasien->tinggal_dengan ?? ''  }}</option>
                            @endif
                          <option value="pasangan">Pasangan</option>
                          <option value="sendiri">Sendiri</option>
                          <option value="anak">Anak</option>
                          <option value="saudara">Saudara</option>
                          </select>
                        @if ($errors->has('tinggal_dengan'))
                          <span id="tinggal_dengan-error" class="error text-danger" for="input-tinggal_dengan">{{ $errors->first('tinggal_dengan') }}</span>
                        @endif
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label">{{ __('Tanggal pemeriksaan terakhir') }}</label>
                    <div class="col-sm-7">
                      <div class="form-group{{ $errors->has('tgl_pemeriksaan_terakhir') ? ' has-danger' : '' }}">
                        <input class="form-control{{ $errors->has('tgl_pemeriksaan_terakhir') ? ' is-invalid' : '' }}" name="tgl_pemeriksaan_terakhir" id="input-tgl_pemeriksaan_terakhir" type="date" placeholder="{{ __('') }}" value="{{ $pasien->tgl_pemeriksaan_terakhir ?? ''  }}" required />
                        @if ($errors->has('tgl_pemeriksaan_terakhir'))
                          <span id="tgl_pemeriksaan_terakhir-error" class="error text-danger" for="input-tgl_pemeriksaan_terakhir">{{ $errors->first('tgl_pemeriksaan_terakhir') }}</span>
                        @endif
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label">{{ __('Hasil pemeriksaan pertama') }}</label>
                    <div class="col-sm-7">
                      <div class="form-group{{ $errors->has('pemeriksaan_satu') ? ' has-danger' : '' }}">
                        <input class="form-control{{ $errors->has('pemeriksaan_satu') ? ' is-invalid' : '' }}" name="pemeriksaan_satu" id="input-pemeriksaan_satu" type="text" placeholder="{{ __('') }}" value="{{ $pasien->pemeriksaan_satu ?? ''  }}" required />
                        @if ($errors->has('pemeriksaan_satu'))
                          <span id="pemeriksaan_satu-error" class="error text-danger" for="input-pemeriksaan_satu">{{ $errors->first('pemeriksaan_satu') }}</span>
                        @endif
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label">{{ __('Hasil pemeriksaan kedua') }}</label>
                    <div class="col-sm-7">
                      <div class="form-group{{ $errors->has('pemeriksaan_dua') ? ' has-danger' : '' }}">
                        <input class="form-control{{ $errors->has('pemeriksaan_dua') ? ' is-invalid' : '' }}" name="pemeriksaan_dua" id="input-pemeriksaan_dua" type="text" placeholder="{{ __('') }}" value="{{ $pasien->pemeriksaan_dua ?? ''  }}" required />
                        @if ($errors->has('pemeriksaan_dua'))
                          <span id="pemeriksaan_dua-error" class="error text-danger" for="input-pemeriksaan_dua">{{ $errors->first('pemeriksaan_dua') }}</span>
                        @endif
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label">{{ __('Penyakit lain') }}</label>
                    <div class="col-sm-7">
                      <div class="form-group{{ $errors->has('penyakit_lain') ? ' has-danger' : '' }}">
                        <input class="form-control{{ $errors->has('penyakit_lain') ? ' is-invalid' : '' }}" name="penyakit_lain" id="input-penyakit_lain" type="text" placeholder="{{ __('') }}" value="{{ $pasien->penyakit_lain ?? ''  }}" required />
                        @if ($errors->has('penyakit_lain'))
                          <span id="penyakit_lain-error" class="error text-danger" for="input-penyakit_lain">{{ $errors->first('penyakit_lain') }}</span>
                        @endif
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label">{{ __('Teratur kontrol') }}</label>
                    <div class="col-sm-7">
                      <div class="form-group{{ $errors->has('teratur_kontrol') ? ' has-danger' : '' }}">
                        <select name="teratur_kontrol" id="teratur_kontrol">
                            @if($pasien->teratur_kontrol)
                            <option value="{{ $pasien->teratur_kontrol ?? ''  }}" selected>{{ $pasien->teratur_kontrol ?? ''  }}</option>
                            @endif
                          <option value="iya">Iya</option>
                          <option value="tidak">Tidak</option>
                          </select>
                        @if ($errors->has('teratur_kontrol'))
                          <span id="teratur_kontrol-error" class="error text-danger" for="input-teratur_kontrol">{{ $errors->first('teratur_kontrol') }}</span>
                        @endif
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label">{{ __('Obat yang dikonsumsi') }}</label>
                    <div class="col-sm-7">
                      <div class="form-group{{ $errors->has('konsumsi_obat') ? ' has-danger' : '' }}">
                        <input class="form-control{{ $errors->has('konsumsi_obat') ? ' is-invalid' : '' }}" name="konsumsi_obat" id="input-konsumsi_obat" type="text" placeholder="{{ __('') }}" value="{{ $pasien->konsumsi_obat ?? ''  }}" required />
                        @if ($errors->has('konsumsi_obat'))
                          <span id="konsumsi_obat-error" class="error text-danger" for="input-konsumsi_obat">{{ $errors->first('konsumsi_obat') }}</span>
                        @endif
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-2 col-form-label">{{ __('Puskesmas') }}</label>
                    <div class="col-sm-7">
                      <div class="form-group{{ $errors->has('puskesmas_id') ? ' has-danger' : '' }}">
                        <select name="puskesmas_id" id="puskesmas_id">

                            @foreach ($puskesmas as $puskesmas) {
                                @if($pasien->puskesmas_id==$puskesmas->id)
                                <option value="{{ $puskesmas->id }}" selected>{{ $puskesmas->nama }}</option>
                                @endif
                          <option value="{{ $puskesmas->id }}">{{ $puskesmas->nama }}</option>
                            }
                            @endforeach
                          </select>
                        @if ($errors->has('puskesmas_id'))
                          <span id="puskesmas_id-error" class="error text-danger" for="input-puskesmas_id">{{ $errors->first('puskesmas_id') }}</span>
                        @endif
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-sm-7">
                      <div class="form-group{{ $errors->has('user_id') ? ' has-danger' : '' }}">
                        <input class="form-control{{ $errors->has('user_id') ? ' is-invalid' : '' }}" name="user_id" id="user_id" type="text" placeholder="{{ __('') }}" value="{{ old('name', auth()->user()->id) }}" required="true" aria-required="true" hidden/>
                        @if ($errors->has('user_id'))
                          <span id="user_id-error" class="error text-danger" for="input-user_id">{{ $errors->first('user_id') }}</span>
                        @endif
                      </div>
                    </div>
                  </div>



              </div>
              <div class="card-footer ml-auto mr-auto">
                <button type="submit" class="btn btn-primary">{{ __('Simpan') }}</button>
              </div>
            </div>
          </form>
        </div>
      </div>

    </div>
  </div>
@endsection
