<div class="sidebar" data-color="orange" data-background-color="white" data-image="{{ asset('material') }}/img/sidebar-1.jpg">
  <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
  <div class="logo">
    <a href="#" class="simple-text logo-normal">
      {{ __('WEB HICORE') }}
    </a>
  </div>
  <div class="sidebar-wrapper">
    <ul class="nav">
        @if(Auth::check()&& Auth::user()->role  == "1")
        <li class="nav-item{{ $activePage ?? '' }}">
            <a class="nav-link" href="{{ route('dataDiri') }}">
              <i class="material-icons">content_paste</i>
                <p>{{ __('Data Diri') }}</p>
            </a>
          </li>
      <li class="nav-item {{ $activePage ?? '' }}">
        <div class="collapse show" id="laravelExample">
          <ul class="nav">
            <li class="nav-item{{ $activePage ?? '' }}">
              <a class="nav-link" href="{{ route('profile.edit') }}">
                <i class="material-icons">perm_identity</i>
                <p>{{ __('Profil') }}</p>
              </a>
            </li>
          </ul>
        </div>
      </li>
      <li class="nav-item {{ $activePage ?? '' }}">
        <div class="collapse show" id="laravelExample">
          <ul class="nav">
            <li class="nav-item{{ $activePage ?? '' }}">
              <a class="nav-link" href="https://forms.gle/N44mhuwfwxNBDheQ9" target="_blank">
                <i class="material-icons">info</i>
                <p>{{ __('Informed Concent') }}</p>
              </a>
            </li>
          </ul>
        </div>
      </li>

      <li class="nav-item{{ $activePage ?? '' }}">
        <a class="nav-link" href="{{ route('typography') }}">
          <i class="material-icons">library_books</i>
            <p>{{ __('Isi Kuesioner') }}</p>
        </a>
      </li>
      <li class="nav-item{{ $activePage ?? '' }}">
        <a class="nav-link" href="{{ route('riwayat') }}">
          <i class="material-icons">content_paste</i>
            <p>{{ __('Riwayat Kuesioner') }}</p>
        </a>
      </li>

        @endif

      @if(Auth::check()&& Auth::user()->role  == "2")
      <li class="nav-item{{ $activePage ?? '' }}">
        <a class="nav-link" href="{{ route('home') }}">
          <i class="material-icons">dashboard</i>
            <p>{{ __('Beranda') }}</p>
        </a>
      </li>
    </li>
    <li class="nav-item {{ $activePage ?? '' }}">
      <div class="collapse show" id="laravelExample">
        <ul class="nav">
          <li class="nav-item{{ $activePage ?? '' }}">
            <a class="nav-link" href="{{ route('profile.edit') }}">
              <i class="material-icons">perm_identity</i>
              <p>{{ __('Profil') }}</p>
            </a>
          </li>
        </ul>
      </div>
    </li>

      <li class="nav-item{{ $activePage ?? '' }}">
          <a class="nav-link" href="{{ route('table') }}">
            <i class="material-icons">face</i>
            <p>{{ __('Hasil Kuesioner Pasien') }}</p>
          </a>
        </li>

      @endif
      <li class="nav-item{{ $activePage ?? '' }}">
        <a class="nav-link" href="{{ route('pendidikanKesehatan') }}">
          <i class="material-icons">face</i>
          <p>{{ __('Pendidikan Kesehatan') }}</p>
        </a>
      </li>
      <li class="nav-item{{ $activePage ?? '' }}">
        <a class="nav-link" href="pilihGroup">
            <i class="material-icons">chat</i>
            <p>{{ __('Konsultasi Group WA') }}</p>
          </a>
      </li>
      <li class="nav-item{{ $activePage ?? '' }}">
        <a class="nav-link" href="https://forms.gle/fUwmVfFg3e3k7TLV9" target="_blank">
            <i class="material-icons">feedback</i>
            <p>{{ __('Tanggapan') }}</p>
          </a>
      </li>
      <li class="nav-item{{ $activePage ?? '' }}">
        <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault();document.getElementById('logout-form').submit();">{{ __('Log out') }}</a>
      </li>

    </ul>
  </div>
</div>
