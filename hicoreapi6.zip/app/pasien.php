<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class pasien extends Model
{
    protected $table='pasien';

    protected $fillable = [
        'id','hp','nama','tgl_lahir','jk','tinggi','berat',
        'alamat','pekerjaan','pendidikan','riwayat_hipertensi_kel',
        'lama_hipertensi','tinggal_dengan','tgl_pemeriksaan_terakhir',
        'pemeriksaan_satu','pemeriksaan_dua','merokok',
        'lama_merokok','rokokperhari','lingkar_perut','penyakit_lain',
        'teratur_kontrol','konsumsi_obat','puskesmas_id','user_id'
    ];
    public function pasien(){
        return $this->belongsTo('App\puskesmas');
    }

    public function pasien_user(){
        return $this->belongsTo('App\User');
    }
}
