<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\puskesmas;
use Illuminate\Support\Facades\DB;
use App\pasien;
use App\kuesioner;
use App\jawaban_kuesioner;

class PasienController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $jpasien=pasien::all()->count();
        $jpuskesmas=puskesmas::all()->count();
        $kuesioner=kuesioner::all()->count();
        $hasil=jawaban_kuesioner::distinct('tanggal')->count();
       // dd($totalpasien);


        $puskesmas=puskesmas::all();
        $id=auth()->user()->id;
        $pasien=DB::table('pasien')->where('user_id',$id)->first();
        $role=auth()->user()->role;
       if($role==1)
       {
        if ($pasien) {
            return view('pages.dataDiriupdate', ['puskesmas'=>$puskesmas,'pasien'=>$pasien]);
        }
        else
        {
            return view('pages.dataDiri', ['puskesmas'=>$puskesmas]);
        }
       }
       else
       {
        return view('dashboard',compact('jpasien','jpuskesmas','kuesioner','hasil'));
       }

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       DB::table('pasien')->insert([
        'id' => auth()->user()->id,
        'hp' => $request->hp,
        'nama' => $request->nama,
        'tgl_lahir' => $request->tgl_lahir,
        'jk' => $request->jk,
        'tinggi' => $request->tinggi,
        'berat'=> $request->berat,
        'alamat' => $request->alamat,
        'pekerjaan' => $request->pekerjaan,
        'pendidikan' => $request->pendidikan,
        'riwayat_hipertensi_kel' => $request->riwayat_hipertensi_kel,
        'lama_hipertensi' => $request->lama_hipertensi,
        'tinggal_dengan' => $request->tinggal_dengan,
        'tgl_pemeriksaan_terakhir' =>$request->tgl_pemeriksaan_terakhir,
        'pemeriksaan_satu' => $request->pemeriksaan_satu,
        'pemeriksaan_dua' => $request->pemeriksaan_dua,
        'merokok' => $request->merokok,
        'lama_merokok' => $request->lama_merokok,
        'rokokperhari' => $request->rokokperhari,
        'lingkar_perut' => $request->lingkar_perut,
        'penyakit_lain' => $request->penyakit_lain,
        'teratur_kontrol' => $request->teratur_kontrol,
        'konsumsi_obat' => $request->konsumsi_obat,
        'puskesmas_id' => $request->puskesmas_id,
        'user_id' => auth()->user()->id
       ]);

        return back()->withStatus(__('Data diri berhasil disimpan'));

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        DB::table('pasien')->where('id',$request->id)->update([
            'hp' => $request->hp,
            'nama' => $request->nama,
            'tgl_lahir' => $request->tgl_lahir,
            'jk' => $request->jk,
            'tinggi' => $request->tinggi,
            'berat'=> $request->berat,
            'alamat' => $request->alamat,
            'pekerjaan' => $request->pekerjaan,
            'pendidikan' => $request->pendidikan,
            'riwayat_hipertensi_kel' => $request->riwayat_hipertensi_kel,
            'lama_hipertensi' => $request->lama_hipertensi,
            'tinggal_dengan' => $request->tinggal_dengan,
            'tgl_pemeriksaan_terakhir' =>$request->tgl_pemeriksaan_terakhir,
            'pemeriksaan_satu' => $request->pemeriksaan_satu,
            'pemeriksaan_dua' => $request->pemeriksaan_dua,
            'merokok' => $request->merokok,
            'lama_merokok' => $request->lama_merokok,
            'rokokperhari' => $request->rokokperhari,
            'lingkar_perut' => $request->lingkar_perut,
            'penyakit_lain' => $request->penyakit_lain,
            'teratur_kontrol' => $request->teratur_kontrol,
            'konsumsi_obat' => $request->konsumsi_obat,
            'puskesmas_id' => $request->puskesmas_id,
           ]);
           return back()->withStatus(__('Data diri berhasil diubah '));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
