

<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <form method="post" action="<?php echo e(route('video_stress.store')); ?>" autocomplete="off" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>

            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Tambah video stress hipertensi')); ?></h4>
              </div>
              <div class="card-body ">
                <?php if(session('status')): ?>
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <i class="material-icons">close</i>
                        </button>
                        <span><?php echo e(session('status')); ?></span>
                      </div>
                    </div>
                  </div>
                <?php endif; ?>
                <div class="row">
                  <label class="col-sm-2 col-form-label"><?php echo e(__('Nama/Judul')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('nama') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('nama') ? ' is-invalid' : ''); ?>" name="nama" id="input-nama" type="text" placeholder="<?php echo e(__('')); ?>" value="" required="true" aria-required="true"/>
                      <?php if($errors->has('nama')): ?>
                        <span id="nama-error" class="error text-danger" for="input-nama"><?php echo e($errors->first('nama')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-2 col-form-label"><?php echo e(__('Link Video (setelah watch?v=)')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('video') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('video') ? ' is-invalid' : ''); ?>" name="video" id="input-video" type="text" placeholder="<?php echo e(__('Contoh : https://www.youtube.com/watch?v=vtt_kJ4kLFw')); ?>" value="" required="true" aria-required="true"/>
                      <?php if($errors->has('video')): ?>
                        <span id="video-error" class="error text-danger" for="input-video"><?php echo e($errors->first('video')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="row">                 
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('jenis_id') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('jenis_id') ? ' is-invalid' : ''); ?>" name="jenis_id" id="input-jenis_id" type="number" placeholder="<?php echo e(__('')); ?>" value="3" required="true" aria-required="true" hidden/>
                      <?php if($errors->has('jenis_id')): ?>
                        <span id="jenis_id-error" class="error text-danger" for="input-jenis_id"><?php echo e($errors->first('jenis_id')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                
              </div>
              <div class="card-footer ml-auto mr-auto">
                <button type="submit" class="btn btn-primary"><?php echo e(__('Simpan')); ?></button>
              </div>
            </div>
          </form>
        </div>
      </div>

    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => '', 'titlePage' => __('')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hicorev2\resources\views/pages/video_stress_insert.blade.php ENDPATH**/ ?>