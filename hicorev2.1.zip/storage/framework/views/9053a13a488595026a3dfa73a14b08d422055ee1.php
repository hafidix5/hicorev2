
<?php /**PATH C:\laragon\www\hicorev2\resources\views/layouts/page_templates/guest.blade.php ENDPATH**/ ?>