

<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header card-header-primary">
            <h4 class="card-title ">Hasil Kuesioner</h4>
            <p class="card-category"></p>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table">
                <thead class=" text-primary">
                <th>
                    Tanggal
                  </th>
                  <th>
                    Nama
                  </th>
                  <th>
                    HP
                  </th>                                  
                  <th>
                    Poin
                  </th>
                  <th>
                    Aksi
                  </th>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $response; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $response): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($response->tanggal); ?></td>
                        <td><?php echo e($response->nama); ?></td>
                        <td><?php echo e($response->hp); ?></td>                    
                        <td><?php echo e($response->skor); ?></td>
                        <td>
                            <a class="nav-link" href="<?php echo e(route('riwayatDetailKuesioner',['tanggal'=>$response->tanggal,'id'=>$response->id])); ?>">
                                <i class="material-icons">visibility</i>
                              </a>
                        </td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Riwayat Kuesioner', 'titlePage' => __('Riwayat Kuesioner')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hicorev2\resources\views/pages/table_list.blade.php ENDPATH**/ ?>