
<?php /**PATH C:\laragon\www\hicorev2\resources\views/layouts/footers/auth.blade.php ENDPATH**/ ?>