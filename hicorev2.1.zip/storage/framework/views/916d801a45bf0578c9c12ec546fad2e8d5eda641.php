

<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container-fluid">

      <div class="row">
        <div class="col-md-12">
          <form method="post" action="<?php echo e(url('notifconfig2/create')); ?>" class="form-horizontal">
            <?php echo e(csrf_field()); ?>

            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Konfigurasi')); ?></h4>
              </div>
              <div class="card-body">

                <?php if($data == null): ?>
                <div class="row">
                    <label class="col-sm-2 col-form-label" for="input-current-password"><?php echo e(__('Pesan')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group">
                        <textarea class="form-control" type="text" name="pesan" placeholder="<?php echo e(__('Pesan')); ?>"  required ></textarea>
                    </div>
                </div>

                  <div class="row">
                      <label class="col-sm-2 col-form-label" for="input-current-password"><?php echo e(__('Durasi Notif')); ?></label>
                      <div class="col-sm-2">
                        <div class="form-group">
                          <input class="form-control"  type="number" name="waktu" placeholder="<?php echo e(__('1')); ?>"  required />
                        </div>
                      </div>
                  </div>

                  <div class="row">
                    <label class="col-sm-2 col-form-label" for="input-current-password"><?php echo e(__('API')); ?></label>
                    <div class="col-sm-2">
                      <div class="form-group">
                        <input class="form-control"  type="text" name="api" placeholder="<?php echo e(__('cxaxaxwxa')); ?>"  required />
                      </div>
                    </div>
                  </div>
                <?php else: ?>
                <div class="row">
                  <label class="col-sm-2 col-form-label" for="input-current-password"><?php echo e(__('Pesan')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group">
                      <input class="form-control"  value="<?php echo e($data->pesan); ?>" type="text" name="pesan" placeholder="<?php echo e(__('Pesan')); ?>"  required ></input>
                    </div>
                  </div>
                </div>

                <div class="row">
                    <label class="col-sm-2 col-form-label" for="input-current-password"><?php echo e(__('Durasi Notif')); ?></label>
                    <div class="col-sm-2">
                      <div class="form-group">
                        <input class="form-control"  value="<?php echo e($data->durasi_hari); ?>" type="number" name="waktu" placeholder="<?php echo e(__('1')); ?>"  required />

                      </div>
                    </div>
                </div>

                <div class="row">
                    <label class="col-sm-2 col-form-label" for="input-current-password"><?php echo e(__('API')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group">
                        <input class="form-control" value="<?php echo e($data->api); ?>" type="text" name="api" placeholder="<?php echo e(__('XXSJENSWOW')); ?>"  required ></input>
                      </div>
                    </div>
                </div>

                <?php endif; ?>
              <div class="card-footer ml-auto mr-auto" style="center">
                <button type="submit" class="btn btn-primary"><?php echo e(__('Simpan ')); ?></button>
              </div>

            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      md.initDashboardPageCharts();
    });
  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Beranda', 'titlePage' => __('Konfigurasi')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hicorev2\resources\views/pages/notifconfig2.blade.php ENDPATH**/ ?>