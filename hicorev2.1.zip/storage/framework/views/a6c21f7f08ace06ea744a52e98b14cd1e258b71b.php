


<?php $__env->startSection('content'); ?>
  <div class="content">
    
      <div class="row">
      <div class="container-fluid">
    <div class="card">
      <div class="card-header card-header-primary">
        <h4 class="card-title">Pertanyaan Pengetahuan</h4>
      </div>
        <div class="col-md-12">

            <div class="card-body">
                <?php if(session('status')): ?>
                <div class="row">
                  <div class="col-sm-12">
                    <div class="alert alert-success">
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <i class="material-icons">close</i>
                      </button>
                      <span><?php echo e(session('status')); ?></span>
                    </div>
                  </div>
                </div>
              <?php endif; ?>
                <div class="table-responsive">
                  <table class="table table-hover">
                    <thead class="">
                        <th>
                            Nomor
                        </th>
                      <th>
                        Pertanyaan
                      </th>
                      <th>
                        Kunci
                      </th>

                    <th>
                        Aksi
                    </th>

                    </thead>
                    <tbody>
                    <?php $no=1; ?>
                        <?php $__currentLoopData = $pertanyaan_pengetahuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pertanyaan_pengetahuan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($pertanyaan_pengetahuan->pertanyaan); ?></td>
                            <?php if($pertanyaan_pengetahuan->kunci==1): ?>
                            <td>Benar</td>
                            <?php else: ?>
                            <td>Salah</td>
                            <?php endif; ?>

                            <td>
                                <a class="nav-link" href="<?php echo e(route('pertanyaan_pengetahuan.edit',$pertanyaan_pengetahuan->id)); ?>">
                                    <i class="material-icons">edit</i> Edit
                                  </a>
                                   <a class="nav-link" href="<?php echo e(route('pertanyaan_pengetahuan.hapus',$pertanyaan_pengetahuan->id)); ?>">
                                    <i class="material-icons">remove_circle</i> Hapus
                                  </a>
                            </td>
                        </tr>
                        <php
                        $no++;
                         ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                  </table>

                </form>

                </div>
              </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <a href="<?php echo e(url('pertanyaan_pengetahuan.insert')); ?>" class="btn btn-xs btn-info pull-left ml-auto">Tambah</a>
                </div>
            </div>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => '' , 'titlePage' => __('')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hicorev2\resources\views/pages/pertanyaan_pengetahuan.blade.php ENDPATH**/ ?>