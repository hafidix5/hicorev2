

<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
         <div class="card">
          <div class="card-header card-header-primary">
            <h4 class="card-title ">Hasil Rekomendasi Kuesioner</h4>
            <p class="card-category"></p>
          </div>
          <div class="card-body">
            <div class="container">
                <div class="row">
                  <div class="col-sm">
                    <div class="card text-center">
                        <h5 class="card-header">Penggunaan Obat-Obatan</h5>
                        <div class="card-body ">
                            <a href="#" class="btn btn-primary disabled">
                                 <?php
                                 $obatr="";
                             ?>
                             <?php $__currentLoopData = $obat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($skor->obat); ?>

                              
                              <?php if($skor->obat=="Tidak patuh"): ?>
                              <?php
                                 $obatr="yes";
                             ?>

                             <?php else: ?>
                              <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </a>
                        </div>
                      </div>
                  </div>
                  <div class="col-sm">
                     <div class="card text-center">
                        <h5 class="card-header">Diet</h5>
                        <div class="card-body">
                            <a href="#" class="btn btn-primary disabled">                              
                              <?php
                                 $dietr="";
                             ?>
                             <?php $__currentLoopData = $diet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($skor->diet); ?>

                              
                              <?php if($skor->diet=="Tidak patuh"): ?>
                              <?php
                                 $dietr="yes";
                             ?>

                             <?php else: ?>
                              <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </a>
                          </div>
                      </div>
                  </div>
                  <div class="col-sm">
                     <div class="card text-center">
                        <h5 class="card-header">Aktifitas Fisik</h5>
                        <div class="card-body">
                            <a href="#" class="btn btn-primary disabled">
                             
                              <?php
                                 $fisikr="";
                             ?>
                             <?php $__currentLoopData = $fisik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($skor->fisik); ?>

                              
                              <?php if($skor->fisik=="Tidak patuh"): ?>
                              <?php
                                 $fisikr="yes";
                             ?>

                             <?php else: ?>
                              <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </a>
                          </div>
                      </div>
                  </div>
                  <div class="col-sm">
                    <div class="card text-center">
                       <h5 class="card-header">Merokok</h5>
                       <div class="card-body">
                           <a href="#" class="btn btn-primary disabled">
                           
                              <?php
                                 $merokokr="";
                             ?>
                             <?php $__currentLoopData = $merokok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($skor->merokok); ?>

                              
                              <?php if($skor->merokok=="Tidak patuh"): ?>
                              <?php
                                 $merokokr="yes";
                             ?>

                             <?php else: ?>
                              <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </a>
                         </div>
                     </div>
                 </div>
                </div>
              </div>
              <div class="container">
                <div class="row">
                  <div class="col-sm">
                     <div class="card text-center">
                        <h5 class="card-header">Manajemen Berat Badan</h5>
                        <div class="card-body">
                            <a href="#" class="btn btn-primary disabled">                            
                              <?php
                                 $beratbadanr="";
                             ?>
                             <?php $__currentLoopData = $beratbadan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($skor->beratbadan); ?>

                             
                              <?php if($skor->beratbadan=="Tidak patuh"): ?>
                              <?php
                                 $beratbadanr="yes";
                             ?>

                             <?php else: ?>
                              <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </a>
                          </div>
                      </div>
                  </div>
                  <div class="col-sm">
                     <div class="card text-center">
                        <h5 class="card-header">Minum Alkohol</h5>
                        <div class="card-body">
                            <a href="#" class="btn btn-primary disabled">
                            
                              <?php
                                 $minumalkoholr="";
                             ?>
                             <?php $__currentLoopData = $minumalkohol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php echo e($skor->minumalkohol); ?>

                              
                              <?php if($skor->minumalkohol=="Tidak patuh"): ?>
                              <?php
                                 $minumalkoholr="yes";
                             ?>

                             <?php else: ?>
                              <?php endif; ?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </a>
                          </div>
                      </div>
                  </div>
                                 
                </div>
              </div>
              <?php
              $rekomendasidmo="";
              $rekomendasima="";
              ?>
              <?php if(($dietr="yes")||($beratbadanr="yes")): ?>
                <?php
                    $rekomendasidmo="Pengaturan Diet Hipertensi dan Manajemen Berat Badan, ";
                ?>
              <?php endif; ?>
              <?php if(($merokokr="yes")||($minumalkoholr="yes")): ?>
              <?php
                  $rekomendasima="Pengenalan Bahaya Rokok dan Alkohol Pada Hipertensi, ";
              ?>
            <?php endif; ?>

              <h4>Rekomendasi :</h4>
              <?php if(($obatr!="")|| ($fisikr!="")|| ($rekomendasidmo!="")|| ($rekomendasima!="")): ?>
              <p>
                Silahkan bapak ibuk untuk mendengarkan kembali pendidikan kesehatan dengan topik <?php echo e($rekomendasidmo); ?> <?php echo e($rekomendasima); ?>

              </p>
              <?php endif; ?>
              <p>
                Segera hubungi petugas kesehatan melalui link whatsapp untuk melakukan konsultasi bila ada yang tidak dipahami
              </p>
              



              <?php if(Auth::check()&& Auth::user()->role  == "2"): ?>
              <a href="<?php echo e(route('downloadHasilKuesioner',$pasien->nama)); ?>" class="btn btn-success my-3" target="_blank">EXPORT EXCEL</a>
              <h4>Pertanyaan kuesioner yang belum dijawab benar</h4>
              <div class="table-responsive">
              <table class="table">
                <thead class=" text-primary">
                  <th>
                    Nomor
                  </th>
                  <th>
                    Pertanyaan
                  </th>

                </thead>
                <tbody>
                    <?php $__currentLoopData = $response; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $response): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                        <td><?php echo e($response->id); ?></td>
                        <td><?php echo e($response->pertanyaan); ?></td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
              </table>
            </div>
            <?php endif; ?>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Riwayat Kuesioner', 'titlePage' => __('Riwayat Kuesioner')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hicorev2\resources\views/pages/hasil_pengendalianDetail.blade.php ENDPATH**/ ?>