

<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="card">
      <div class="card-header card-header-primary">
        <h4 class="card-title">Isi kuesioner Tindakan Perawatan/pengendalian Diri  Penderita Hipertensi</h4>
      </div>

      <div class="card-body col-sm-10">
        <iframe src="<?php echo e(asset('material')); ?>/img/silence.mp3" type="audio/mp3" allow="autoplay" id="audio" style="display: none"></iframe>
        <audio id="player" autoplay loop>
          <source src="<?php echo e(asset('material')); ?>/img/hicore.mp3" type="audio/mp3">
      </audio>
        <?php if(session('status')): ?>
        <div class="row">
          <div class="col-sm-12">
            <div class="alert alert-success">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <i class="material-icons">close</i>
              </button>
              <span><?php echo e(session('status')); ?></span>
            </div>
          </div>
        </div>
      <?php endif; ?>
        <div class="table-responsive">
          <table class="table table-hover">
            <thead class="">
              <th>
                Nomor
              </th>
              <th>
                Pertanyaan
              </th>
              <th>
                Jawaban&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp;
              </th>

            </thead>
            <tbody>
                <form method="post" action="<?php echo e(route('isi_pengendalianSave')); ?>" autocomplete="off" class="form-horizontal">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('post'); ?>
            <?php $no=1; ?>
            <tr><td style="font-weight:bold;">Penggunaan Obat-obatan</td>
            </tr>
            <?php $__currentLoopData = $pengendalian_1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengendalian_1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($pengendalian_1->pertanyaan); ?></td>
                    <td class="text-left">
                        <span><input type="radio" id=<?php echo e($pengendalian_1->id); ?> name=<?php echo e($pengendalian_1->id); ?> value="-1" required/> Tidak diresepkan obat</span><br>
                        <span><input type="radio" id=<?php echo e($pengendalian_1->id); ?> name=<?php echo e($pengendalian_1->id); ?> value="0"/> 0</span>
                       <span><input type="radio" id=<?php echo e($pengendalian_1->id); ?> name=<?php echo e($pengendalian_1->id); ?> value="1"/> 1</span>
                       <span><input type="radio" id=<?php echo e($pengendalian_1->id); ?> name=<?php echo e($pengendalian_1->id); ?> value="2"/> 2</span><br>
                       <span><input type="radio" id=<?php echo e($pengendalian_1->id); ?> name=<?php echo e($pengendalian_1->id); ?> value="3"/> 3</span>
                       <span><input type="radio" id=<?php echo e($pengendalian_1->id); ?> name=<?php echo e($pengendalian_1->id); ?> value="4"/> 4</span>
                       <span><input type="radio" id=<?php echo e($pengendalian_1->id); ?> name=<?php echo e($pengendalian_1->id); ?> value="5"/> 5</span><br>
                       <span><input type="radio" id=<?php echo e($pengendalian_1->id); ?> name=<?php echo e($pengendalian_1->id); ?> value="6"/> 6</span>
                       <span><input type="radio" id=<?php echo e($pengendalian_1->id); ?> name=<?php echo e($pengendalian_1->id); ?> value="7"/> 7</span>
                   </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr><td style="font-weight:bold;">Diet</td>
            </tr>
            <?php $__currentLoopData = $pengendalian_2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengendalian_2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($pengendalian_2->pertanyaan); ?></td>
                    <td class="text-left">
                        <span><input type="radio" id=<?php echo e($pengendalian_2->id); ?> name=<?php echo e($pengendalian_2->id); ?> value="0" required/> 0</span>
                       <span><input type="radio" id=<?php echo e($pengendalian_2->id); ?> name=<?php echo e($pengendalian_2->id); ?> value="1"/> 1</span>
                       <span><input type="radio" id=<?php echo e($pengendalian_2->id); ?> name=<?php echo e($pengendalian_2->id); ?> value="2"/> 2</span><br>
                       <span><input type="radio" id=<?php echo e($pengendalian_2->id); ?> name=<?php echo e($pengendalian_2->id); ?> value="3"/> 3</span>
                       <span><input type="radio" id=<?php echo e($pengendalian_2->id); ?> name=<?php echo e($pengendalian_2->id); ?> value="4"/> 4</span>
                       <span><input type="radio" id=<?php echo e($pengendalian_2->id); ?> name=<?php echo e($pengendalian_2->id); ?> value="5"/> 5</span><br>
                       <span><input type="radio" id=<?php echo e($pengendalian_2->id); ?> name=<?php echo e($pengendalian_2->id); ?> value="6"/> 6</span>
                       <span><input type="radio" id=<?php echo e($pengendalian_2->id); ?> name=<?php echo e($pengendalian_2->id); ?> value="7"/> 7</span>
                   </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr><td style="font-weight:bold;">Aktivitas Fisik</td>
            </tr>
            <?php $__currentLoopData = $pengendalian_3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengendalian_3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($pengendalian_3->pertanyaan); ?></td>
                    <td class="text-left">
                        <span><input type="radio" id=<?php echo e($pengendalian_3->id); ?> name=<?php echo e($pengendalian_3->id); ?> value="0" required/> 0</span>
                       <span><input type="radio" id=<?php echo e($pengendalian_3->id); ?> name=<?php echo e($pengendalian_3->id); ?> value="1"/> 1</span>
                       <span><input type="radio" id=<?php echo e($pengendalian_3->id); ?> name=<?php echo e($pengendalian_3->id); ?> value="2"/> 2</span><br>
                       <span><input type="radio" id=<?php echo e($pengendalian_3->id); ?> name=<?php echo e($pengendalian_3->id); ?> value="3"/> 3</span>
                       <span><input type="radio" id=<?php echo e($pengendalian_3->id); ?> name=<?php echo e($pengendalian_3->id); ?> value="4"/> 4</span>
                       <span><input type="radio" id=<?php echo e($pengendalian_3->id); ?> name=<?php echo e($pengendalian_3->id); ?> value="5"/> 5</span><br>
                       <span><input type="radio" id=<?php echo e($pengendalian_3->id); ?> name=<?php echo e($pengendalian_3->id); ?> value="6"/> 6</span>
                       <span><input type="radio" id=<?php echo e($pengendalian_3->id); ?> name=<?php echo e($pengendalian_3->id); ?> value="7"/> 7</span>
                   </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr><td style="font-weight:bold;">Merokok</td>
            </tr>
            <?php $__currentLoopData = $pengendalian_4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengendalian_4): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($pengendalian_4->pertanyaan); ?></td>
                    <td class="text-left">
                        <span><input type="radio" id=<?php echo e($pengendalian_4->id); ?> name=<?php echo e($pengendalian_4->id); ?> value="0" required/> 0</span>
                       <span><input type="radio" id=<?php echo e($pengendalian_4->id); ?> name=<?php echo e($pengendalian_4->id); ?> value="1"/> 1</span>
                       <span><input type="radio" id=<?php echo e($pengendalian_4->id); ?> name=<?php echo e($pengendalian_4->id); ?> value="2"/> 2</span><br>
                       <span><input type="radio" id=<?php echo e($pengendalian_4->id); ?> name=<?php echo e($pengendalian_4->id); ?> value="3"/> 3</span>
                       <span><input type="radio" id=<?php echo e($pengendalian_4->id); ?> name=<?php echo e($pengendalian_4->id); ?> value="4"/> 4</span>
                       <span><input type="radio" id=<?php echo e($pengendalian_4->id); ?> name=<?php echo e($pengendalian_4->id); ?> value="5"/> 5</span><br>
                       <span><input type="radio" id=<?php echo e($pengendalian_4->id); ?> name=<?php echo e($pengendalian_4->id); ?> value="6"/> 6</span>
                       <span><input type="radio" id=<?php echo e($pengendalian_4->id); ?> name=<?php echo e($pengendalian_4->id); ?> value="7"/> 7</span>
                   </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr><td style="font-weight:bold;">Manajemen Berat Badan</td>
            </tr>
            <?php $__currentLoopData = $pengendalian_5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengendalian_5): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($pengendalian_5->pertanyaan); ?></td>
                    <td class="text-left">
                        <span><input type="radio" id=<?php echo e($pengendalian_5->id); ?> name=<?php echo e($pengendalian_5->id); ?> value="0" required/> Sangat tidak setuju</span><br>
                       <span><input type="radio" id=<?php echo e($pengendalian_5->id); ?> name=<?php echo e($pengendalian_5->id); ?> value="1"/> Tidak setuju</span><br>
                       <span><input type="radio" id=<?php echo e($pengendalian_5->id); ?> name=<?php echo e($pengendalian_5->id); ?> value="2"/> Tidak Yakin</span><br>
                       <span><input type="radio" id=<?php echo e($pengendalian_5->id); ?> name=<?php echo e($pengendalian_5->id); ?> value="3"/> Setuju</span><br>
                       <span><input type="radio" id=<?php echo e($pengendalian_5->id); ?> name=<?php echo e($pengendalian_5->id); ?> value="4"/> Sangat Setuju</span>
                   </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php $__currentLoopData = $pengendalian_6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengendalian_6): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($pengendalian_6->pertanyaan); ?></td>
                    <td class="text-left">
                        <span><input type="radio" id=<?php echo e($pengendalian_6->id); ?> name=<?php echo e($pengendalian_6->id); ?> value="0" required/> 0</span>
                       <span><input type="radio" id=<?php echo e($pengendalian_6->id); ?> name=<?php echo e($pengendalian_6->id); ?> value="1"/> 1</span>
                       <span><input type="radio" id=<?php echo e($pengendalian_6->id); ?> name=<?php echo e($pengendalian_6->id); ?> value="2"/> 2</span><br>
                       <span><input type="radio" id=<?php echo e($pengendalian_6->id); ?> name=<?php echo e($pengendalian_6->id); ?> value="3"/> 3</span>
                       <span><input type="radio" id=<?php echo e($pengendalian_6->id); ?> name=<?php echo e($pengendalian_6->id); ?> value="4"/> 4</span>
                       <span><input type="radio" id=<?php echo e($pengendalian_6->id); ?> name=<?php echo e($pengendalian_6->id); ?> value="5"/> 5</span><br>
                       <span><input type="radio" id=<?php echo e($pengendalian_6->id); ?> name=<?php echo e($pengendalian_6->id); ?> value="6"/> 6</span>
                       <span><input type="radio" id=<?php echo e($pengendalian_6->id); ?> name=<?php echo e($pengendalian_6->id); ?> value="7"/> 7</span>
                   </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $pengendalian_7; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengendalian_7): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($pengendalian_7->pertanyaan); ?></td>
                    <td class="text-left">
                        <span><input type="text" id=<?php echo e($pengendalian_7->id); ?> name=<?php echo e($pengendalian_7->id); ?> value="" required/> </span>

                   </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           

            </tbody>
          </table>
          <div class="card-footer ml-auto mr-auto">
            <button type="submit" class="btn btn-primary"><?php echo e(__('Simpan')); ?></button>
          </div>
        </form>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => '', 'titlePage' => __('')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hicorev2\resources\views/pages/isi_pengendalian.blade.php ENDPATH**/ ?>