

<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
         <div class="card">
          <div class="card-header card-header-primary">
            <h4 class="card-title ">Hasil status kesehatan</h4>
            <p class="card-category"></p>
          </div>
          <div class="card-body">
            <div class="container">
                <div class="row">
                  <div class="col-sm">
                    <div class="card text-center">
                        <h5 class="card-header">Tekanan Darah</h5>
                        <div class="card-body ">
                            <a href="#" class="btn btn-primary disabled">
                                <?php $__currentLoopData = $tekanandarah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tekanandarahs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($tekanandarahs->tekanandarah); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </a>
                        </div>
                      </div>
                  </div>
                  <div class="col-sm">
                     <div class="card text-center">
                        <h5 class="card-header">Indek Masa Tubuh</h5>
                        <div class="card-body">
                            <a href="#" class="btn btn-primary disabled">
                                <?php $__currentLoopData = $imt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($imts->imt); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </a>
                          </div>
                      </div>
                  </div>
                  <div class="col-sm">
                     <div class="card text-center">
                        <h5 class="card-header">Obesitas</h5>
                        <div class="card-body">
                            <a href="#" class="btn btn-primary disabled">
                                <?php $__currentLoopData = $obesitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obesitass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($obesitass->obesitas); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </a>
                          </div>
                      </div>
                  </div>
                  <div class="col-sm">
                    <div class="card text-center">
                       <h5 class="card-header">Rokok</h5>
                       <div class="card-body">
                           <a href="#" class="btn btn-primary disabled">
                            <?php $__currentLoopData = $rokok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rokoks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($rokoks->rokok); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </a>
                         </div>
                     </div>
                 </div>
                </div>
              </div>


            </div>
            <div class="card-footer ml-auto mr-auto">
                <a href="<?php echo e(url('status_kesehatan')); ?>" class="btn btn-xs btn-info pull-left ml-auto">Kembali</a>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hicorev2\resources\views/pages/status_kesehatanHasil.blade.php ENDPATH**/ ?>