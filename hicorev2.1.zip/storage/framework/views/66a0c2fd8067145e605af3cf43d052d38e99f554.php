

<?php $__env->startSection('content'); ?>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <form method="post" action="<?php echo e(route('pasien.update')); ?>" autocomplete="off" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>

            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"><?php echo e(__('Data Pasien')); ?></h4>
              </div>
              <div class="card-body ">
                <iframe src="<?php echo e(asset('material')); ?>/img/silence.mp3" type="audio/mp3" allow="autoplay" id="audio" style="display: none"></iframe>
                <audio id="player" autoplay loop>
                  <source src="<?php echo e(asset('material')); ?>/img/hicore.mp3" type="audio/mp3">
              </audio>
                <?php if(session('status')): ?>
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <i class="material-icons">close</i>
                        </button>
                        <span><?php echo e(session('status')); ?></span>
                      </div>
                    </div>
                  </div>
                <?php endif; ?>
                <input type="hidden" name="id" value="<?php echo e($pasien->id); ?>">
                <div class="row">
                  <label class="col-sm-3 col-form-label"><?php echo e(__('Nama Lengkap')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('nama') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('nama') ? ' is-invalid' : ''); ?>" name="nama" id="input-nama" type="text" placeholder="<?php echo e(__('Nama')); ?>" value="<?php echo e(old('name', auth()->user()->name)); ?>" required="true" aria-required="true" readonly/>
                      <?php if($errors->has('nama')): ?>
                        <span id="nama-error" class="error text-danger" for="input-nama"><?php echo e($errors->first('nama')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <label class="col-sm-3 col-form-label"><?php echo e(__('HP')); ?></label>
                  <div class="col-sm-7">
                    <div class="form-group<?php echo e($errors->has('hp') ? ' has-danger' : ''); ?>">
                      <input class="form-control<?php echo e($errors->has('hp') ? ' is-invalid' : ''); ?>" name="hp" id="input-hp" type="phone" placeholder="<?php echo e(__('Nomor HP')); ?>" value="<?php echo e($pasien->hp ?? ''); ?>" required readonly/>
                      <?php if($errors->has('hp')): ?>
                        <span id="hp-error" class="error text-danger" for="input-hp"><?php echo e($errors->first('hp')); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                    <label class="col-sm-3 col-form-label"><?php echo e(__('Tanggal lahir')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('tgl_lahir') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('tgl_lahir') ? ' is-invalid' : ''); ?>" name="tgl_lahir" id="input-tgl_lahir" type="date" placeholder="<?php echo e(__('')); ?>" value="<?php echo e($pasien->tgl_lahir ?? ''); ?>" required />
                        <?php if($errors->has('tgl_lahir')): ?>
                          <span id="tgl_lahir-error" class="error text-danger" for="input-tgl_lahir"><?php echo e($errors->first('tgl_lahir')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-3 col-form-label"><?php echo e(__('Jenis kelamin')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('jk') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="jk" id="jk">
                          <?php if($pasien->jk): ?>
                          <option value="<?php echo e($pasien->jk ?? ''); ?>" selected><?php echo e($pasien->jk ?? ''); ?></option>
                          <option value="laki-laki">Laki-laki</option>
                          <option value="perempuan">Perempuan</option>
                          <?php endif; ?>
                        </select>
                        <?php if($errors->has('jk')): ?>
                          <span id="jk-error" class="error text-danger" for="input-jk"><?php echo e($errors->first('jk')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <label class="col-sm-3 col-form-label"><?php echo e(__('Alamat tinggal')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('alamat') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('alamat') ? ' is-invalid' : ''); ?>" name="alamat" id="input-alamat" type="text" placeholder="<?php echo e(__('alamat tempat tinggal')); ?>" value="<?php echo e($pasien->alamat ?? ''); ?>" required />
                        <?php if($errors->has('alamat')): ?>
                          <span id="alamat-error" class="error text-danger" for="input-alamat"><?php echo e($errors->first('alamat')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-3 col-form-label"><?php echo e(__('Pekerjaan')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('pekerjaan') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="pekerjaan" id="pekerjaan">
                          <?php if($pasien->pekerjaan): ?>
                          <option value="<?php echo e($pasien->pekerjaan ?? ''); ?>" selected><?php echo e($pasien->pekerjaan ?? ''); ?></option>
                          <?php endif; ?>
                          <option value="Ibu rumah tangga">Ibu rumah tangga</option>
                          <option value="Pensiunan">Pensiunan</option>
                          <option value="PNS">PNS</option>
                          <option value="Petani/Buruh">Petani/Buruh</option>
                          <option value="Wiraswasta">Wiraswasta</option>
                          <option value="Tidak bekerja">Tidak bekerja</option>
                        </select>
                        <?php if($errors->has('pekerjaan')): ?>
                          <span id="pekerjaan-error" class="error text-danger" for="input-pekerjaan"><?php echo e($errors->first('pekerjaan')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-3 col-form-label"><?php echo e(__('Tingkat Pendidikan')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('pendidikan') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="pendidikan" id="pendidikan">
                            <?php if($pasien->pendidikan): ?>
                            <option value="<?php echo e($pasien->pendidikan ?? ''); ?>" selected><?php echo e($pasien->pendidikan ?? ''); ?></option>
                            <?php endif; ?>
                          <option value="Tidak Sekolah">Tidak Sekolah</option>
                          <option value="SD">SD</option>
                          <option value="SMP">SMP</option>
                          <option value="SMA">SMA</option>
                          <option value="Perguruan Tinggi">Perguruan Tinggi</option>
                        </select>
                        <?php if($errors->has('pendidikan')): ?>
                          <span id="pendidikan-error" class="error text-danger" for="input-pendidikan"><?php echo e($errors->first('pendidikan')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-3 col-form-label"><?php echo e(__('Adakah keluarga (orangtua,kakek/nenek) yang memiliki Penyakit  Hipertensi')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('riwayat_hipertensi_kel') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="riwayat_hipertensi_kel" id="riwayat_hipertensi_kel">
                            <?php if($pasien->riwayat_hipertensi_kel): ?>
                            <option value="<?php echo e($pasien->riwayat_hipertensi_kel ?? ''); ?>" selected><?php echo e($pasien->riwayat_hipertensi_kel ?? ''); ?></option>
                            <?php endif; ?>
                          <option value="ada">Ada</option>
                          <option value="tidak">Tidak</option>
                          </select>
                        <?php if($errors->has('riwayat_hipertensi_kel')): ?>
                          <span id="riwayat_hipertensi_kel-error" class="error text-danger" for="input-riwayat_hipertensi_kel"><?php echo e($errors->first('riwayat_hipertensi_kel')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <label class="col-sm-3 col-form-label"><?php echo e(__('Sebutkan Siapa')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('sebutkan_siapa') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="sebutkan_siapa" id="sebutkan_siapa">
                            <?php if($pasien->sebutkan_siapa): ?>
                            <option value="<?php echo e($pasien->sebutkan_siapa ?? ''); ?>" selected><?php echo e($pasien->sebutkan_siapa ?? ''); ?></option>
                            <?php endif; ?>
                          <option value="tidak ada">Tidak Ada</option>
                          <option value="ayah">Ayah</option>
                          <option value="ibu">Ibu</option>
                          <option value="kakek">Kakek</option>
                          <option value="nenek">Nenek</option>
                          </select>
                        <?php if($errors->has('sebutkan_siapa')): ?>
                          <span id="sebutkan_siapa-error" class="error text-danger" for="input-sebutkan_siapa"><?php echo e($errors->first('sebutkan_siapa')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-3 col-form-label"><?php echo e(__('Lama menderita hipertensi ')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('lama_hipertensiTahun') ? ' has-danger' : ''); ?> col-sm-2">
                        <input class="form-control<?php echo e($errors->has('lama_hipertensiTahun') ? ' is-invalid' : ''); ?> " name="lama_hipertensiTahun" id="input-lama_hipertensiTahun" type="number" placeholder="<?php echo e(__('')); ?>" value="<?php echo e($pasien->lama_hipertensiTahun ?? ''); ?>" required /> Tahun
                        <input class="form-control<?php echo e($errors->has('lama_hipertensi') ? ' is-invalid' : ''); ?> " name="lama_hipertensi" id="input-lama_hipertensi" type="number" placeholder="<?php echo e(__('')); ?>" value="<?php echo e($pasien->lama_hipertensi ?? ''); ?>" required /> Bulan

                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-3 col-form-label"><?php echo e(__('Adakah Penyakit lain yang dimiliki selain hipertensi')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('penyakit_lain_cek') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="penyakit_lain_cek" id="penyakit_lain_cek">
                            <?php if($pasien->penyakit_lain_cek): ?>
                            <option value="<?php echo e($pasien->penyakit_lain_cek ?? ''); ?>" selected><?php echo e($pasien->penyakit_lain_cek ?? ''); ?></option>
                            <?php endif; ?>
                          <option value="tidak ada">Tidak Ada</option>
                          <option value="ada">Ada</option>
                          </select>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-3 col-form-label"><?php echo e(__('Sebutkan penyakit tersebut')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('penyakit_lain') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('penyakit_lain') ? ' is-invalid' : ''); ?>" name="penyakit_lain" id="input-penyakit_lain" type="text" placeholder="<?php echo e(__('')); ?>" value="<?php echo e($pasien->penyakit_lain ?? ''); ?>" required />
                        <?php if($errors->has('penyakit_lain')): ?>
                          <span id="penyakit_lain-error" class="error text-danger" for="input-penyakit_lain"><?php echo e($errors->first('penyakit_lain')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-3 col-form-label"><?php echo e(__('Apakah anda teratur kontrol setiap bulan ke Pelayanan kesehatan')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('teratur_kontrol') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="teratur_kontrol" id="teratur_kontrol">
                            <?php if($pasien->teratur_kontrol): ?>
                            <option value="<?php echo e($pasien->teratur_kontrol ?? ''); ?>" selected><?php echo e($pasien->teratur_kontrol ?? ''); ?></option>
                            <?php endif; ?>
                          <option value="iya">Iya</option>
                          <option value="tidak">Tidak</option>
                          </select>
                        <?php if($errors->has('teratur_kontrol')): ?>
                          <span id="teratur_kontrol-error" class="error text-danger" for="input-teratur_kontrol"><?php echo e($errors->first('teratur_kontrol')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-3 col-form-label"><?php echo e(__('Jika tidak teratur kontrol, apa alasannya ')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('alasan') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('alasan') ? ' is-invalid' : ''); ?>" name="alasan" id="input-alasan" type="text" placeholder="<?php echo e(__('')); ?>" value="<?php echo e($pasien->alasan ?? ''); ?>" required />
                        <?php if($errors->has('alasan')): ?>
                          <span id="alasan-error" class="error text-danger" for="input-alasan"><?php echo e($errors->first('alasan')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-3 col-form-label"><?php echo e(__('Nama obat hipertensi yang diminum saat ini')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('konsumsi_obat') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('konsumsi_obat') ? ' is-invalid' : ''); ?>" name="konsumsi_obat" id="input-konsumsi_obat" type="text" placeholder="<?php echo e(__('')); ?>" value="<?php echo e($pasien->konsumsi_obat ?? ''); ?>" required />
                        <?php if($errors->has('konsumsi_obat')): ?>
                          <span id="konsumsi_obat-error" class="error text-danger" for="input-konsumsi_obat"><?php echo e($errors->first('konsumsi_obat')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-3 col-form-label"><?php echo e(__('Tinggal serumah bersama dengan ')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('tinggal_dengan') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="tinggal_dengan" id="tinggal_dengan">
                            <?php if($pasien->tinggal_dengan): ?>
                            <option value="<?php echo e($pasien->tinggal_dengan ?? ''); ?>" selected><?php echo e($pasien->tinggal_dengan ?? ''); ?></option>
                            <?php endif; ?>
                          <option value="pasangan">Pasangan</option>
                          <option value="sendiri">Sendiri</option>
                          <option value="anak">Anak</option>
                          <option value="saudara">Saudara</option>
                          </select>
                        <?php if($errors->has('tinggal_dengan')): ?>
                          <span id="tinggal_dengan-error" class="error text-danger" for="input-tinggal_dengan"><?php echo e($errors->first('tinggal_dengan')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-3 col-form-label"><?php echo e(__('Pilih tempat berobat')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('jenis_tempat_berobat') ? ' has-danger' : ''); ?>">
                        <select class="form-control" name="jenis_tempat_berobat" id="jenis_tempat_berobat">
                            <?php if($pasien->jenis_tempat_berobat): ?>
                            <option value="<?php echo e($pasien->jenis_tempat_berobat ?? ''); ?>" selected><?php echo e($pasien->jenis_tempat_berobat ?? ''); ?></option>
                            <?php endif; ?>
                            <option value="puskemas">Puskemas</option>
                            <option value="klinik">Klinik</option>
                            <option value="rumah sakit">Rumah Sakit</option>
                        </select>
                        <?php if($errors->has('jenis_tempat_berobat')): ?>
                          <span id="jenis_tempat_berobat-error" class="error text-danger" for="input-jenis_tempat_berobat"><?php echo e($errors->first('jenis_tempat_berobat')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-3 col-form-label"><?php echo e(__('Nama tempat berobat')); ?></label>
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('nama_tempat_berobat') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('nama_tempat_berobat') ? ' is-invalid' : ''); ?>" name="nama_tempat_berobat" id="input-nama_tempat_berobat" type="text" placeholder="<?php echo e(__('')); ?>" value="<?php echo e($pasien->nama_tempat_berobat ?? ''); ?>" required />
                        <?php if($errors->has('nama_tempat_berobat')): ?>
                          <span id="nama_tempat_berobat-error" class="error text-danger" for="input-nama_tempat_berobat"><?php echo e($errors->first('nama_tempat_berobat')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-sm-7">
                      <div class="form-group<?php echo e($errors->has('user_id') ? ' has-danger' : ''); ?>">
                        <input class="form-control<?php echo e($errors->has('user_id') ? ' is-invalid' : ''); ?>" name="user_id" id="user_id" type="text" placeholder="<?php echo e(__('')); ?>" value="<?php echo e(old('name', auth()->user()->id)); ?>" required="true" aria-required="true" hidden/>
                        <?php if($errors->has('user_id')): ?>
                          <span id="user_id-error" class="error text-danger" for="input-user_id"><?php echo e($errors->first('user_id')); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>



              </div>
              <div class="card-footer ml-auto mr-auto">
                <button type="submit" class="btn btn-primary"><?php echo e(__('Simpan')); ?></button>
              </div>
            </div>
          </form>
        </div>
      </div>

    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'Data Diri', 'titlePage' => __('Data Diri')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hicorev2\resources\views/pages/dataDiriupdate.blade.php ENDPATH**/ ?>